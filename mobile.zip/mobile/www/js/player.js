/**
 * Player module: join a hunt (code or QR), pick a team, play the steps,
 * and reach the final screen.
 */
const Player = {
  render(arg) {
    const parts = (arg || '').split('/');
    const sub = parts[0] || 'hub';
    if (sub === 'join') return this.joinScreen();
    if (sub === 'step') return this.stepScreen(parseInt(parts[1], 10));
    if (sub === 'final') return this.finalScreen();
    return this.hubScreen();
  },

  session() { return Store.getSession(); },

  // ---------- Join ----------
  joinScreen() {
    App.applyTheme(null);
    const pending = sessionStorage.getItem('hunter.pendingCode') || '';
    App.setScreen(`
      <div class="screen">
        ${App.header('Rejoindre', 'home')}
        <div class="form join-form">
          <div class="join-illus">🎯</div>
          <label>Code de la chasse</label>
          <input id="joinCode" class="code-input" value="${App.esc(pending)}"
            placeholder="ABC123" maxlength="10" autocapitalize="characters" autocorrect="off" spellcheck="false">
          <button class="btn ghost" id="scanBtn">📷 Scanner un QR code</button>
          <button class="btn primary" id="findBtn">Continuer</button>
          <div id="joinInfo"></div>
        </div>
      </div>
    `, {
      onMount: () => {
        App.bindBack('home');
        const input = document.getElementById('joinCode');
        input.addEventListener('input', () => { input.value = input.value.toUpperCase(); });
        document.getElementById('findBtn').addEventListener('click', () => this.resolveAndJoin(input.value));
        document.getElementById('scanBtn').addEventListener('click', async () => {
          const raw = await App.scanQr();
          if (!raw) return;
          const code = this.extractCode(raw);
          input.value = code;
          this.resolveAndJoin(code);
        });
        if (pending) { sessionStorage.removeItem('hunter.pendingCode'); }
      }
    });
  },

  extractCode(raw) {
    try {
      const u = new URL(raw);
      return (u.searchParams.get('j') || u.searchParams.get('join') || u.searchParams.get('code') || raw).toUpperCase();
    } catch (e) {
      return String(raw).toUpperCase().replace(/[^A-Z0-9]/g, '');
    }
  },

  async resolveAndJoin(code) {
    code = (code || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
    if (!code) { App.toast('Entrez un code.', 'err'); return; }
    const info = document.getElementById('joinInfo');
    info.innerHTML = '<p class="loading">Recherche…</p>';
    try {
      const hunt = await Api.resolveCode(code);
      App.applyTheme(hunt.theme);
      info.innerHTML = `
        <div class="found">
          <h3>${App.esc(hunt.title)}</h3>
          <p>${App.esc(hunt.subtitle || '')}</p>
          <p class="steps-count">${hunt.totalSteps} étape(s)</p>
          <label>Nom de votre équipe</label>
          <input id="teamName" maxlength="50" placeholder="Les Aventuriers">
          <button class="btn primary" id="doJoin">C'est parti !</button>
        </div>`;
      document.getElementById('doJoin').addEventListener('click', async () => {
        const name = document.getElementById('teamName').value.trim();
        if (!name) { App.toast('Choisissez un nom d\'équipe.', 'err'); return; }
        try {
          const res = await Api.join(hunt.huntId, name, []);
          Store.setSession({
            huntId: res.huntId, teamId: res.teamId, teamName: res.teamName,
            joinCode: hunt.joinCode, title: hunt.title, theme: hunt.theme,
            totalSteps: res.totalSteps
          });
          App.go('play/hub');
        } catch (e) { App.handleError(e); }
      });
    } catch (e) {
      info.innerHTML = `<p class="test-result err">${App.esc(e.message)}</p>`;
    }
  },

  // ---------- Hub ----------
  async hubScreen() {
    const s = this.session();
    if (!s) return App.go('play/join');
    App.applyTheme(s.theme);
    App.setScreen(`<div class="screen"><p class="loading">Chargement…</p></div>`);
    try {
      const data = await Api.getSteps(s.huntId, s.teamId);
      App.setScreen(`
        <div class="screen hub">
          <div class="topbar">
            <button class="icon-btn" data-quit aria-label="Quitter">✕</button>
            <h2>${App.esc(data.title)}</h2>
            <span class="spacer"></span>
          </div>
          <div class="hub-progress">
            <span>${data.completedCount}/${data.totalSteps} étapes</span>
            <div class="progress"><div class="progress-bar" style="width:${Math.round(data.completedCount / data.totalSteps * 100)}%"></div></div>
          </div>
          <div class="grid">
            ${data.steps.map(st => `
              <button class="tile ${st.isCompleted ? 'done' : ''}" data-step="${st.number}">
                <span class="tile-icon">${st.isCompleted ? '✅' : st.icon}</span>
                <span class="tile-num">Étape ${st.number}</span>
                <span class="tile-title">${App.esc(st.title)}</span>
              </button>`).join('')}
          </div>
          ${data.allCompleted ? `<button class="btn primary big" data-final>🏆 Voir le trésor</button>` : ''}
        </div>
      `, {
        onMount: () => {
          this.root().querySelector('[data-quit]').addEventListener('click', () => {
            if (confirm('Quitter la partie ? Votre progression est sauvegardée sur le serveur.')) App.go('home');
          });
          this.root().querySelectorAll('[data-step]').forEach(b =>
            b.addEventListener('click', () => App.go(`play/step/${b.getAttribute('data-step')}`)));
          const f = this.root().querySelector('[data-final]');
          if (f) f.addEventListener('click', () => App.go('play/final'));
        }
      });
    } catch (e) { App.handleError(e); }
  },
  root() { return document.getElementById('app'); },

  // ---------- Step ----------
  async stepScreen(n) {
    const s = this.session();
    if (!s) return App.go('play/join');
    App.setScreen(`<div class="screen"><p class="loading">Chargement…</p></div>`);
    try {
      const step = await Api.getStep(s.huntId, s.teamId, n);
      this.currentStep = step;
      App.setScreen(`
        <div class="screen step">
          ${App.header(`Étape ${n}`, 'play/hub')}
          <div class="step-body">
            <div class="step-type">${this.icon(step.type)} ${Organizer.typeLabel(step.type)}</div>
            <h2>${App.esc(step.title)}</h2>
            ${step.image ? `<img class="step-img" src="${App.esc(step.image)}" alt="">` : ''}
            <p class="step-desc">${App.nl2br(step.description)}</p>
            ${step.isCompleted ? '<div class="banner ok">✅ Étape déjà validée</div>' : ''}
            <div id="answerArea"></div>
            ${step.isCompleted ? '' : `<button class="btn primary" id="submitBtn">Valider</button>`}
            <div id="feedback"></div>
            <div id="hintBox"></div>
          </div>
        </div>
      `, {
        onMount: () => {
          App.bindBack('play/hub');
          this.renderAnswerArea(step);
          const btn = document.getElementById('submitBtn');
          if (btn) btn.addEventListener('click', () => this.submit(n, step));
        }
      });
    } catch (e) { App.handleError(e); }
  },

  icon(t) {
    return ({
      single_answer: '✏️', puzzle: '🧩', cipher: '🔐', multiple_answers: '📝',
      qcm: '🎯', matching: '🔗', order: '📋', multi_questions: '📝', photo_upload: '📷'
    })[t] || '❓';
  },

  renderAnswerArea(step) {
    const area = document.getElementById('answerArea');
    if (step.isCompleted && step.type !== 'photo_upload') { area.innerHTML = ''; return; }
    const t = step.type;
    if (t === 'single_answer' || t === 'puzzle') {
      area.innerHTML = `<input class="ans" id="a-single" placeholder="Votre réponse">`;
    } else if (t === 'cipher') {
      area.innerHTML = `<input class="ans code-input" id="a-single" placeholder="Code" autocapitalize="characters">`;
    } else if (t === 'multiple_answers') {
      const labels = step.fieldLabels || [];
      area.innerHTML = Array.from({ length: step.fieldCount }, (_, i) =>
        `<input class="ans multi" placeholder="${App.esc(labels[i] || 'Réponse ' + (i + 1))}">`).join('');
    } else if (t === 'qcm') {
      area.innerHTML = step.choices.map((c, i) =>
        `<label class="choice"><input type="${step.multiSelect ? 'checkbox' : 'radio'}" name="qcm" value="${App.esc(c)}"> ${App.esc(c)}</label>`).join('');
    } else if (t === 'matching') {
      area.innerHTML = step.leftItems.map((l, i) => `
        <div class="match-row">
          <span>${App.esc(l)}</span>
          <select data-left="${App.esc(l)}">
            <option value="">— choisir —</option>
            ${step.rightItems.map(r => `<option value="${App.esc(r)}">${App.esc(r)}</option>`).join('')}
          </select>
        </div>`).join('');
    } else if (t === 'order') {
      this.orderItems = step.items.slice();
      area.innerHTML = `<div id="orderList" class="order-list"></div>`;
      this.renderOrderList();
    } else if (t === 'multi_questions') {
      area.innerHTML = step.questions.map((q, i) => `
        <div class="subq-play">
          <p>${App.esc(q.description)}</p>
          ${q.hint ? `<small class="hint">💡 ${App.esc(q.hint)}</small>` : ''}
          <input class="ans mq" placeholder="Réponse">
        </div>`).join('');
    } else if (t === 'photo_upload') {
      area.innerHTML = `
        <input type="file" accept="image/*" capture="environment" id="photoInput" hidden>
        <button class="btn primary" id="pickPhoto">📷 Prendre / choisir une photo</button>
        <div id="photoPreview"></div>`;
      document.getElementById('pickPhoto').addEventListener('click', () => document.getElementById('photoInput').click());
      document.getElementById('photoInput').addEventListener('change', e => this.handlePhoto(e, step));
    }
  },

  renderOrderList() {
    const list = document.getElementById('orderList');
    list.innerHTML = this.orderItems.map((it, i) => `
      <div class="order-item">
        <span>${App.esc(it)}</span>
        <span class="ord-ctrls">
          <button data-up="${i}" ${i === 0 ? 'disabled' : ''}>▲</button>
          <button data-down="${i}" ${i === this.orderItems.length - 1 ? 'disabled' : ''}>▼</button>
        </span>
      </div>`).join('');
    list.querySelectorAll('[data-up]').forEach(b => b.addEventListener('click', () => {
      const i = +b.getAttribute('data-up');[this.orderItems[i - 1], this.orderItems[i]] = [this.orderItems[i], this.orderItems[i - 1]]; this.renderOrderList();
    }));
    list.querySelectorAll('[data-down]').forEach(b => b.addEventListener('click', () => {
      const i = +b.getAttribute('data-down');[this.orderItems[i + 1], this.orderItems[i]] = [this.orderItems[i], this.orderItems[i + 1]]; this.renderOrderList();
    }));
  },

  collectAnswer(step) {
    const t = step.type;
    if (t === 'single_answer' || t === 'puzzle' || t === 'cipher') {
      return document.getElementById('a-single').value.trim();
    }
    if (t === 'multiple_answers') {
      return Array.from(document.querySelectorAll('.ans.multi')).map(i => i.value.trim());
    }
    if (t === 'qcm') {
      return Array.from(document.querySelectorAll('input[name="qcm"]:checked')).map(i => i.value);
    }
    if (t === 'matching') {
      const obj = {};
      document.querySelectorAll('[data-left]').forEach(sel => { obj[sel.getAttribute('data-left')] = sel.value; });
      return obj;
    }
    if (t === 'order') return this.orderItems.slice();
    if (t === 'multi_questions') {
      return Array.from(document.querySelectorAll('.ans.mq')).map(i => i.value.trim());
    }
    return null;
  },

  async submit(n, step) {
    const answer = this.collectAnswer(step);
    const fb = document.getElementById('feedback');
    fb.innerHTML = '<p class="loading">Vérification…</p>';
    try {
      const res = await Api.submitAnswer(this.session().huntId, this.session().teamId, n, answer);
      if (res.valid) {
        fb.innerHTML = `<div class="banner ok">✅ ${App.esc(res.message)}</div>`;
        setTimeout(() => { if (res.isFinished) App.go('play/final'); else App.go('play/hub'); }, 900);
      } else {
        fb.innerHTML = `<div class="banner err">❌ ${App.esc(res.message)}</div>`;
        if (res.hint) document.getElementById('hintBox').innerHTML = `<div class="banner hint-banner">💡 ${App.esc(res.hint)}</div>`;
      }
    } catch (e) { App.handleError(e); fb.innerHTML = ''; }
  },

  handlePhoto(e, step) {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async () => {
      const base64 = reader.result.split(',')[1];
      document.getElementById('photoPreview').innerHTML = `<img class="step-img" src="${reader.result}" alt="">`;
      const fb = document.getElementById('feedback');
      fb.innerHTML = '<p class="loading">Envoi…</p>';
      try {
        const res = await Api.uploadPhoto(this.session().huntId, this.session().teamId, step.number, base64, file.type);
        fb.innerHTML = `<div class="banner ok">✅ ${App.esc(res.message)}</div>`;
        setTimeout(() => { if (res.isFinished) App.go('play/final'); else App.go('play/hub'); }, 1100);
      } catch (err) { App.handleError(err); fb.innerHTML = ''; }
    };
    reader.readAsDataURL(file);
  },

  // ---------- Final ----------
  async finalScreen() {
    const s = this.session();
    if (!s) return App.go('play/join');
    App.setScreen(`<div class="screen"><p class="loading">Chargement…</p></div>`);
    try {
      const data = await Api.getFinal(s.huntId, s.teamId);
      App.setScreen(`
        <div class="screen final">
          <div class="confetti">🎉</div>
          <h1>Bravo ${App.esc(data.teamName)} !</h1>
          ${data.finalImage ? `<img class="final-img" src="${App.esc(data.finalImage)}" alt="">` : ''}
          <p class="final-msg">${App.nl2br(data.finalMessage)}</p>
          <div class="final-stats">
            <span>⏱️ ${App.esc(data.duration)}</span>
            <span>🎯 ${data.totalAttempts} tentative(s)</span>
          </div>
          <button class="btn primary" data-home>Terminer</button>
        </div>
      `, {
        onMount: () => {
          this.root().querySelector('[data-home]').addEventListener('click', () => App.go('home'));
        }
      });
    } catch (e) {
      App.handleError(e);
      App.go('play/hub');
    }
  }
};
