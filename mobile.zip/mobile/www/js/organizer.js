/**
 * Organizer module: create/configure a hunt, share it (code / QR / link),
 * and monitor teams in real time.
 */
const Organizer = {
  state: null, // { huntId, token, joinCode, config }

  // Create a brand-new hunt on the server, then open the editor.
  async createNew() {
    try {
      App.toast('Création…');
      const res = await Api.createHunt(undefined);
      Store.saveMyHunt({
        huntId: res.huntId, organizerToken: res.organizerToken,
        joinCode: res.joinCode, title: res.config.title
      });
      App.go(`organizer/${res.huntId}`);
    } catch (e) { App.handleError(e); }
  },

  async render(huntId) {
    const saved = Store.getMyHunts().find(h => h.huntId === huntId);
    if (!saved) {
      App.toast('Chasse introuvable sur cet appareil.', 'err');
      return App.go('home');
    }
    try {
      const res = await Api.getHunt(huntId, saved.organizerToken);
      this.state = {
        huntId, token: saved.organizerToken,
        joinCode: res.joinCode, config: res.config
      };
      App.applyTheme(res.config.theme);
      this.renderEditor();
    } catch (e) {
      App.handleError(e);
    }
  },

  renderEditor() {
    const c = this.state.config;
    App.setScreen(`
      <div class="screen editor">
        ${App.header(c.title || 'Ma chasse', 'home')}
        <div class="tabbar">
          <button class="tab active" data-tab="config">Configuration</button>
          <button class="tab" data-tab="steps">Étapes (${c.steps.length})</button>
          <button class="tab" data-tab="share">Partager</button>
          <button class="tab" data-tab="monitor">Suivi</button>
        </div>
        <div id="tabContent"></div>
      </div>
    `, {
      onMount: () => {
        App.bindBack('home');
        this.root().querySelectorAll('.tab').forEach(t => {
          t.addEventListener('click', () => {
            this.root().querySelectorAll('.tab').forEach(x => x.classList.remove('active'));
            t.classList.add('active');
            this.showTab(t.getAttribute('data-tab'));
          });
        });
        this.showTab('config');
      }
    });
  },
  root() { return document.getElementById('app'); },
  tabEl() { return document.getElementById('tabContent'); },

  showTab(tab) {
    if (tab === 'config') return this.tabConfig();
    if (tab === 'steps') return this.tabSteps();
    if (tab === 'share') return this.tabShare();
    if (tab === 'monitor') return this.tabMonitor();
  },

  // ---------- Tab: general configuration ----------
  tabConfig() {
    const c = this.state.config;
    this.tabEl().innerHTML = `
      <div class="form">
        <label>Titre de la chasse</label>
        <input id="f-title" value="${App.esc(c.title)}" maxlength="120">

        <label>Sous-titre</label>
        <input id="f-subtitle" value="${App.esc(c.subtitle)}" maxlength="240">

        <label>Message de fin (affiché à la victoire)</label>
        <textarea id="f-final" rows="3" maxlength="2000">${App.esc(c.finalMessage)}</textarea>

        <label>Image de fin (URL, optionnel)</label>
        <input id="f-finalimg" value="${App.esc(c.finalImage)}" placeholder="https://…">

        <div class="colors">
          <div><label>Couleur 1</label><input type="color" id="f-c1" value="${c.theme.primaryColor}"></div>
          <div><label>Couleur 2</label><input type="color" id="f-c2" value="${c.theme.secondaryColor}"></div>
          <div><label>Couleur 3</label><input type="color" id="f-c3" value="${c.theme.accentColor}"></div>
        </div>

        <button class="btn primary" id="saveConfig">💾 Enregistrer</button>
        <button class="btn danger ghost" id="deleteHunt">Supprimer cette chasse</button>
      </div>
    `;
    document.getElementById('saveConfig').addEventListener('click', () => this.saveConfigTab());
    document.getElementById('deleteHunt').addEventListener('click', () => this.deleteHunt());
    ['f-c1', 'f-c2', 'f-c3'].forEach(id => {
      document.getElementById(id).addEventListener('input', () => {
        App.applyTheme({
          primaryColor: document.getElementById('f-c1').value,
          secondaryColor: document.getElementById('f-c2').value,
          accentColor: document.getElementById('f-c3').value
        });
      });
    });
  },

  readConfigTab() {
    const c = this.state.config;
    const g = id => document.getElementById(id);
    if (g('f-title')) {
      c.title = g('f-title').value.trim() || 'Ma Chasse au Trésor';
      c.subtitle = g('f-subtitle').value.trim();
      c.finalMessage = g('f-final').value;
      c.finalImage = g('f-finalimg').value.trim();
      c.theme = {
        primaryColor: g('f-c1').value,
        secondaryColor: g('f-c2').value,
        accentColor: g('f-c3').value
      };
    }
  },

  async saveConfigTab() {
    this.readConfigTab();
    await this.persist('Configuration enregistrée ✓');
  },

  async persist(msg) {
    try {
      await Api.updateHunt(this.state.huntId, this.state.token, this.state.config);
      Store.saveMyHunt({
        huntId: this.state.huntId, organizerToken: this.state.token,
        joinCode: this.state.joinCode, title: this.state.config.title
      });
      if (msg) App.toast(msg);
      return true;
    } catch (e) { App.handleError(e); return false; }
  },

  async deleteHunt() {
    if (!confirm('Supprimer définitivement cette chasse et toutes les équipes ?')) return;
    try {
      await Api.deleteHunt(this.state.huntId, this.state.token);
      Store.removeMyHunt(this.state.huntId);
      App.toast('Chasse supprimée.');
      App.go('home');
    } catch (e) { App.handleError(e); }
  },

  // ---------- Tab: steps ----------
  tabSteps() {
    const steps = this.state.config.steps;
    this.tabEl().innerHTML = `
      <div class="steps-editor">
        ${steps.length === 0 ? '<p class="empty">Aucune étape. Ajoutez votre première énigme !</p>' : ''}
        <div class="step-list">
          ${steps.map((s, i) => `
            <div class="step-item">
              <span class="step-num">${i + 1}</span>
              <span class="step-info">
                <strong>${App.esc(s.title)}</strong>
                <small>${this.typeLabel(s.type)}</small>
              </span>
              <span class="step-ctrls">
                <button data-move="up" data-i="${i}" aria-label="Monter" ${i === 0 ? 'disabled' : ''}>▲</button>
                <button data-move="down" data-i="${i}" aria-label="Descendre" ${i === steps.length - 1 ? 'disabled' : ''}>▼</button>
                <button data-edit="${i}" aria-label="Éditer">✏️</button>
                <button data-del="${i}" class="del" aria-label="Supprimer">🗑️</button>
              </span>
            </div>`).join('')}
        </div>
        <button class="btn primary" id="addStep">＋ Ajouter une étape</button>
      </div>
    `;
    document.getElementById('addStep').addEventListener('click', () => this.editStep(-1));
    this.tabEl().querySelectorAll('[data-edit]').forEach(b =>
      b.addEventListener('click', () => this.editStep(parseInt(b.getAttribute('data-edit'), 10))));
    this.tabEl().querySelectorAll('[data-del]').forEach(b =>
      b.addEventListener('click', () => this.delStep(parseInt(b.getAttribute('data-del'), 10))));
    this.tabEl().querySelectorAll('[data-move]').forEach(b =>
      b.addEventListener('click', () => this.moveStep(parseInt(b.getAttribute('data-i'), 10), b.getAttribute('data-move'))));
  },

  typeLabel(t) {
    return ({
      single_answer: 'Réponse libre', puzzle: 'Énigme', cipher: 'Code secret',
      multiple_answers: 'Réponses multiples', qcm: 'QCM', matching: 'Associations',
      order: 'Remise en ordre', multi_questions: 'Questions multiples', photo_upload: 'Photo'
    })[t] || t;
  },

  async delStep(i) {
    if (!confirm('Supprimer cette étape ?')) return;
    this.state.config.steps.splice(i, 1);
    await this.persist('Étape supprimée.');
    this.tabSteps();
  },
  async moveStep(i, dir) {
    const steps = this.state.config.steps;
    const j = dir === 'up' ? i - 1 : i + 1;
    if (j < 0 || j >= steps.length) return;
    [steps[i], steps[j]] = [steps[j], steps[i]];
    await this.persist();
    this.tabSteps();
  },

  // Step editor overlay
  editStep(index) {
    const isNew = index < 0;
    const step = isNew
      ? { title: '', type: 'single_answer', description: '', image: '', hint: '', answers: [''] }
      : JSON.parse(JSON.stringify(this.state.config.steps[index]));

    const overlay = document.createElement('div');
    overlay.className = 'overlay';
    overlay.innerHTML = `
      <div class="sheet">
        <div class="sheet-head">
          <h3>${isNew ? 'Nouvelle étape' : 'Modifier l\'étape'}</h3>
          <button class="icon-btn" id="closeSheet">✕</button>
        </div>
        <div class="form" id="stepForm">
          <label>Titre</label>
          <input id="s-title" value="${App.esc(step.title)}" maxlength="120">

          <label>Type d'épreuve</label>
          <select id="s-type">
            ${['single_answer', 'puzzle', 'cipher', 'multiple_answers', 'qcm', 'matching', 'order', 'multi_questions', 'photo_upload']
        .map(t => `<option value="${t}" ${t === step.type ? 'selected' : ''}>${this.typeLabel(t)}</option>`).join('')}
          </select>

          <label>Description / énoncé</label>
          <textarea id="s-desc" rows="3" maxlength="3000">${App.esc(step.description)}</textarea>

          <label>Image (URL, optionnel)</label>
          <input id="s-image" value="${App.esc(step.image || '')}" placeholder="https://…">

          <label>Indice (optionnel, révélé après 3 essais)</label>
          <input id="s-hint" value="${App.esc(step.hint || '')}">

          <div id="typeFields"></div>
        </div>
        <div class="sheet-foot">
          <button class="btn ghost" id="cancelStep">Annuler</button>
          <button class="btn primary" id="saveStep">Valider</button>
        </div>
      </div>`;
    document.body.appendChild(overlay);

    const close = () => overlay.remove();
    overlay.querySelector('#closeSheet').addEventListener('click', close);
    overlay.querySelector('#cancelStep').addEventListener('click', close);

    const typeSel = overlay.querySelector('#s-type');
    const renderFields = () => this.renderTypeFields(overlay, typeSel.value, step);
    typeSel.addEventListener('change', renderFields);
    renderFields();

    overlay.querySelector('#saveStep').addEventListener('click', async () => {
      const built = this.readStepForm(overlay, step);
      if (!built) return;
      if (isNew) this.state.config.steps.push(built);
      else this.state.config.steps[index] = built;
      if (await this.persist('Étape enregistrée ✓')) {
        close();
        this.tabSteps();
      }
    });
  },

  // Dynamic per-type fields
  renderTypeFields(overlay, type, step) {
    const box = overlay.querySelector('#typeFields');
    const listEditor = (label, arr, ph) => `
      <label>${label}</label>
      <div class="list-editor" data-list>
        ${(arr && arr.length ? arr : ['']).map(v => this.listRow(v, ph)).join('')}
      </div>
      <button type="button" class="btn tiny add-row">＋ Ajouter</button>`;

    let html = '';
    if (type === 'single_answer' || type === 'puzzle') {
      html = listEditor('Réponses acceptées', step.answers, 'Réponse');
    } else if (type === 'cipher') {
      html = listEditor('Code(s) accepté(s)', step.answers, 'Code');
    } else if (type === 'multiple_answers') {
      html = listEditor('Réponses (toutes requises, ordre libre)', step.answers, 'Réponse');
    } else if (type === 'qcm') {
      html = `${listEditor('Choix proposés', step.choices, 'Choix')}
        <label>Bonne(s) réponse(s) — recopiez exactement les choix corrects</label>
        <div class="list-editor" data-list2>
          ${(step.answers && step.answers.length ? step.answers : ['']).map(v => this.listRow(v, 'Bonne réponse')).join('')}
        </div>
        <button type="button" class="btn tiny add-row2">＋ Ajouter</button>`;
    } else if (type === 'order') {
      html = listEditor('Éléments dans le BON ordre', step.correctOrder, 'Élément');
    } else if (type === 'matching') {
      html = `<label>Associations (gauche ↔ droite)</label>
        <div class="pairs" data-pairs>
          ${(step.pairs && step.pairs.length ? step.pairs : [{ left: '', right: '' }]).map(p => this.pairRow(p)).join('')}
        </div>
        <button type="button" class="btn tiny add-pair">＋ Ajouter une paire</button>`;
    } else if (type === 'multi_questions') {
      html = `<label>Sous-questions</label>
        <div class="subq" data-subq>
          ${(step.questions && step.questions.length ? step.questions : [{ description: '', answers: [''] }]).map(q => this.subqRow(q)).join('')}
        </div>
        <button type="button" class="btn tiny add-subq">＋ Ajouter une question</button>`;
    } else if (type === 'photo_upload') {
      html = `<p class="hint">Les joueurs valident cette étape en envoyant une photo. Aucune réponse à définir.</p>`;
    }
    box.innerHTML = html;
    this.wireListButtons(box);
  },

  listRow(v, ph) {
    return `<div class="lrow"><input value="${App.esc(v)}" placeholder="${App.esc(ph || '')}"><button type="button" class="rm">✕</button></div>`;
  },
  pairRow(p) {
    return `<div class="prow">
      <input class="pl" value="${App.esc(p.left)}" placeholder="Gauche">
      <span>↔</span>
      <input class="pr" value="${App.esc(p.right)}" placeholder="Droite">
      <button type="button" class="rm">✕</button></div>`;
  },
  subqRow(q) {
    return `<div class="sqrow">
      <input class="sq-desc" value="${App.esc(q.description || '')}" placeholder="Question">
      <div class="list-editor sq-answers">
        ${(q.answers && q.answers.length ? q.answers : ['']).map(a => this.listRow(a, 'Réponse')).join('')}
      </div>
      <button type="button" class="btn tiny add-sq-ans">＋ réponse</button>
      <button type="button" class="rm-subq">Supprimer la question</button>
    </div>`;
  },

  wireListButtons(scope) {
    const bind = (sel, handler) => scope.querySelectorAll(sel).forEach(b => b.addEventListener('click', handler));
    scope.querySelectorAll('.rm').forEach(b => b.addEventListener('click', e => {
      const row = e.target.closest('.lrow, .prow');
      if (row) row.remove();
    }));
    bind('.add-row', e => {
      e.target.previousElementSibling.insertAdjacentHTML('beforeend', this.listRow('', 'Réponse'));
      this.wireListButtons(e.target.previousElementSibling);
    });
    bind('.add-row2', e => {
      e.target.previousElementSibling.insertAdjacentHTML('beforeend', this.listRow('', 'Bonne réponse'));
      this.wireListButtons(e.target.previousElementSibling);
    });
    bind('.add-pair', e => {
      e.target.previousElementSibling.insertAdjacentHTML('beforeend', this.pairRow({ left: '', right: '' }));
      this.wireListButtons(e.target.previousElementSibling);
    });
    bind('.add-subq', e => {
      e.target.previousElementSibling.insertAdjacentHTML('beforeend', this.subqRow({ description: '', answers: [''] }));
      this.wireListButtons(e.target.previousElementSibling);
    });
    bind('.add-sq-ans', e => {
      const list = e.target.previousElementSibling;
      list.insertAdjacentHTML('beforeend', this.listRow('', 'Réponse'));
      this.wireListButtons(list);
    });
    scope.querySelectorAll('.rm-subq').forEach(b => b.addEventListener('click', e => {
      const row = e.target.closest('.sqrow'); if (row) row.remove();
    }));
  },

  readList(container) {
    if (!container) return [];
    return Array.from(container.querySelectorAll(':scope > .lrow > input'))
      .map(i => i.value.trim()).filter(v => v.length);
  },

  readStepForm(overlay, prev) {
    const g = sel => overlay.querySelector(sel);
    const type = g('#s-type').value;
    const step = {
      title: g('#s-title').value.trim() || 'Étape',
      type,
      description: g('#s-desc').value,
      image: g('#s-image').value.trim(),
      hint: g('#s-hint').value.trim()
    };
    const box = g('#typeFields');

    if (type === 'single_answer' || type === 'puzzle' || type === 'cipher' || type === 'multiple_answers') {
      step.answers = this.readList(box.querySelector('[data-list]'));
      if (!step.answers.length) { App.toast('Ajoutez au moins une réponse.', 'err'); return null; }
    } else if (type === 'qcm') {
      step.choices = this.readList(box.querySelector('[data-list]'));
      step.answers = this.readList(box.querySelector('[data-list2]'));
      if (step.choices.length < 2) { App.toast('Ajoutez au moins 2 choix.', 'err'); return null; }
      if (!step.answers.length) { App.toast('Indiquez la/les bonne(s) réponse(s).', 'err'); return null; }
    } else if (type === 'order') {
      step.correctOrder = this.readList(box.querySelector('[data-list]'));
      if (step.correctOrder.length < 2) { App.toast('Ajoutez au moins 2 éléments.', 'err'); return null; }
    } else if (type === 'matching') {
      step.pairs = Array.from(box.querySelectorAll('.prow')).map(r => ({
        left: r.querySelector('.pl').value.trim(), right: r.querySelector('.pr').value.trim()
      })).filter(p => p.left && p.right);
      if (!step.pairs.length) { App.toast('Ajoutez au moins une paire.', 'err'); return null; }
    } else if (type === 'multi_questions') {
      step.questions = Array.from(box.querySelectorAll('.sqrow')).map(r => ({
        description: r.querySelector('.sq-desc').value.trim(),
        answers: this.readList(r.querySelector('.sq-answers'))
      })).filter(q => q.description && q.answers.length);
      if (!step.questions.length) { App.toast('Ajoutez au moins une question complète.', 'err'); return null; }
    }
    return step;
  },

  // ---------- Tab: share ----------
  tabShare() {
    if (this.state.config.steps.length === 0) {
      this.tabEl().innerHTML = `<p class="empty">Ajoutez au moins une étape avant de partager.</p>`;
      return;
    }
    const code = this.state.joinCode;
    const base = Store.getApiBase();
    const link = `${base}/?j=${code}`;
    this.tabEl().innerHTML = `
      <div class="share">
        <p class="share-lead">Les joueurs peuvent rejoindre de 3 façons :</p>
        <div class="qr-wrap" id="qrWrap"></div>
        <div class="code-big">${App.esc(code)}</div>
        <p class="share-link">${App.esc(link)}</p>
        <div class="share-btns">
          <button class="btn primary" id="shareBtn">📤 Partager le lien</button>
          <button class="btn ghost" id="copyCode">Copier le code</button>
          <button class="btn ghost" id="copyLink">Copier le lien</button>
        </div>
      </div>`;
    try {
      const canvas = QRGen.toCanvas(link, 260);
      document.getElementById('qrWrap').appendChild(canvas);
    } catch (e) {
      document.getElementById('qrWrap').innerHTML = '<p class="hint">QR indisponible — utilisez le code ou le lien.</p>';
    }
    document.getElementById('shareBtn').addEventListener('click', () =>
      App.share(`Rejoins ma chasse au trésor "${this.state.config.title}" !\nCode : ${code}\n${link}`, this.state.config.title));
    document.getElementById('copyCode').addEventListener('click', () => App.copy(code));
    document.getElementById('copyLink').addEventListener('click', () => App.copy(link));
  },

  // ---------- Tab: monitor ----------
  async tabMonitor() {
    this.tabEl().innerHTML = `<p class="loading">Chargement…</p>`;
    try {
      const data = await Api.getTeams(this.state.huntId, this.state.token);
      if (!data.teams.length) {
        this.tabEl().innerHTML = `<p class="empty">Aucune équipe n'a encore rejoint.</p>
          <button class="btn ghost" id="refresh">↻ Rafraîchir</button>`;
      } else {
        this.tabEl().innerHTML = `
          <div class="monitor">
            <button class="btn ghost small" id="refresh">↻ Rafraîchir</button>
            ${data.teams.map(t => {
          const done = t.completedSteps.length;
          const pct = Math.round(done / t.totalSteps * 100);
          return `<div class="team-card">
                <div class="team-head">
                  <strong>${App.esc(t.name)}</strong>
                  <span>${done}/${t.totalSteps} ${t.completedAt ? '🏁' : ''}</span>
                </div>
                <div class="progress"><div class="progress-bar" style="width:${pct}%"></div></div>
                <div class="dots">
                  ${Array.from({ length: t.totalSteps }, (_, i) =>
            `<span class="dot ${t.completedSteps.includes(i + 1) ? 'on' : ''}"></span>`).join('')}
                </div>
                <button class="btn tiny danger ghost" data-delteam="${t.id}">Supprimer l'équipe</button>
              </div>`;
        }).join('')}
          </div>`;
      }
      const r = document.getElementById('refresh');
      if (r) r.addEventListener('click', () => this.tabMonitor());
      this.tabEl().querySelectorAll('[data-delteam]').forEach(b =>
        b.addEventListener('click', async () => {
          if (!confirm('Supprimer cette équipe ?')) return;
          await Api.deleteTeam(this.state.huntId, this.state.token, b.getAttribute('data-delteam'));
          this.tabMonitor();
        }));
    } catch (e) { App.handleError(e); }
  }
};
