/**
 * Minimal, dependency-free QR Code generator (byte mode, EC level L,
 * versions 1..10). Enough to encode a short share URL or join code so the
 * mobile app works fully offline. Renders into a <canvas>.
 *
 * Algorithm adapted from the public QR Code specification (ISO/IEC 18004).
 * Exposes: QRGen.toCanvas(text, sizePx) -> HTMLCanvasElement
 */
(function (global) {
  'use strict';

  // ---- Galois field GF(256) ----
  var EXP = new Array(256), LOG = new Array(256);
  (function () {
    var x = 1;
    for (var i = 0; i < 255; i++) {
      EXP[i] = x;
      LOG[x] = i;
      x <<= 1;
      if (x & 0x100) x ^= 0x11d;
    }
  })();
  function gmul(a, b) {
    if (a === 0 || b === 0) return 0;
    return EXP[(LOG[a] + LOG[b]) % 255];
  }
  function rsGenerator(n) {
    var g = [1];
    for (var i = 0; i < n; i++) {
      var ng = new Array(g.length + 1);
      for (var k = 0; k < ng.length; k++) ng[k] = 0;
      for (var j = 0; j < g.length; j++) {
        ng[j] ^= g[j];
        ng[j + 1] ^= gmul(g[j], EXP[i]);
      }
      g = ng;
    }
    return g;
  }
  function rsEncode(data, ecLen) {
    var gen = rsGenerator(ecLen);
    var res = data.slice();
    for (var i = 0; i < ecLen; i++) res.push(0);
    for (var i = 0; i < data.length; i++) {
      var coef = res[i];
      if (coef !== 0) {
        for (var j = 0; j < gen.length; j++) res[i + j] ^= gmul(gen[j], coef);
      }
    }
    return res.slice(data.length);
  }

  // ---- Version tables (EC level L) ----
  // groups: [ [numBlocks, dataCodewordsPerBlock], ... ]; ec = EC codewords/block
  var VERSIONS = {
    1: { ec: 7, groups: [[1, 19]] },
    2: { ec: 10, groups: [[1, 34]] },
    3: { ec: 15, groups: [[1, 55]] },
    4: { ec: 20, groups: [[1, 80]] },
    5: { ec: 26, groups: [[1, 108]] },
    6: { ec: 18, groups: [[2, 68]] },
    7: { ec: 20, groups: [[2, 78]] },
    8: { ec: 24, groups: [[2, 97]] },
    9: { ec: 30, groups: [[2, 116]] },
    10: { ec: 18, groups: [[2, 68], [2, 69]] }
  };
  var ALIGN = {
    1: [], 2: [6, 18], 3: [6, 22], 4: [6, 26], 5: [6, 30],
    6: [6, 34], 7: [6, 22, 38], 8: [6, 24, 42], 9: [6, 26, 46], 10: [6, 28, 50]
  };

  function dataCapacity(v) {
    var total = 0;
    VERSIONS[v].groups.forEach(function (g) { total += g[0] * g[1]; });
    return total; // data codewords
  }

  // ---- BCH helpers for format & version info ----
  var G15 = 0x537, G15_MASK = 0x5412, G18 = 0x1f25;
  function bchDigit(d) { var n = 0; while (d !== 0) { n++; d >>>= 1; } return n; }
  function bchTypeInfo(data) {
    var d = data << 10;
    while (bchDigit(d) - bchDigit(G15) >= 0) d ^= (G15 << (bchDigit(d) - bchDigit(G15)));
    return ((data << 10) | d) ^ G15_MASK;
  }
  function bchTypeNumber(data) {
    var d = data << 12;
    while (bchDigit(d) - bchDigit(G18) >= 0) d ^= (G18 << (bchDigit(d) - bchDigit(G18)));
    return (data << 12) | d;
  }

  function maskFn(p, i, j) {
    switch (p) {
      case 0: return (i + j) % 2 === 0;
      case 1: return i % 2 === 0;
      case 2: return j % 3 === 0;
      case 3: return (i + j) % 3 === 0;
      case 4: return (Math.floor(i / 2) + Math.floor(j / 3)) % 2 === 0;
      case 5: return (i * j) % 2 + (i * j) % 3 === 0;
      case 6: return ((i * j) % 2 + (i * j) % 3) % 2 === 0;
      case 7: return ((i * j) % 3 + (i + j) % 2) % 2 === 0;
    }
    return false;
  }

  // ---- Encode text -> bit list ----
  function encodeData(text, version) {
    var bytes = [];
    for (var i = 0; i < text.length; i++) {
      var c = text.charCodeAt(i);
      if (c < 0x80) bytes.push(c);
      else if (c < 0x800) { bytes.push(0xc0 | (c >> 6), 0x80 | (c & 0x3f)); }
      else { bytes.push(0xe0 | (c >> 12), 0x80 | ((c >> 6) & 0x3f), 0x80 | (c & 0x3f)); }
    }
    var bits = [];
    function put(val, len) { for (var b = len - 1; b >= 0; b--) bits.push((val >> b) & 1); }
    put(4, 4); // byte mode
    var countBits = version <= 9 ? 8 : 16;
    put(bytes.length, countBits);
    bytes.forEach(function (b) { put(b, 8); });

    var capacityBits = dataCapacity(version) * 8;
    // terminator
    for (var t = 0; t < 4 && bits.length < capacityBits; t++) bits.push(0);
    // pad to byte boundary
    while (bits.length % 8 !== 0) bits.push(0);
    // pad bytes
    var pad = [0xec, 0x11], pi = 0;
    while (bits.length < capacityBits) { put(pad[pi], 8); pi ^= 1; }

    // to codewords
    var cw = [];
    for (var k = 0; k < bits.length; k += 8) {
      var v = 0;
      for (var b = 0; b < 8; b++) v = (v << 1) | bits[k + b];
      cw.push(v);
    }
    return { bytes: bytes.length, codewords: cw };
  }

  function chooseVersion(text) {
    for (var v = 1; v <= 10; v++) {
      var countBits = v <= 9 ? 8 : 16;
      var byteLen = utf8Len(text);
      var need = 4 + countBits + byteLen * 8;
      if (need <= dataCapacity(v) * 8) return v;
    }
    throw new Error('Texte trop long pour le QR code.');
  }
  function utf8Len(text) {
    var n = 0;
    for (var i = 0; i < text.length; i++) {
      var c = text.charCodeAt(i);
      n += c < 0x80 ? 1 : c < 0x800 ? 2 : 3;
    }
    return n;
  }

  // ---- Interleave blocks + EC ----
  function buildFinalCodewords(codewords, version) {
    var spec = VERSIONS[version];
    var blocks = [];
    var offset = 0;
    spec.groups.forEach(function (g) {
      for (var b = 0; b < g[0]; b++) {
        var data = codewords.slice(offset, offset + g[1]);
        offset += g[1];
        blocks.push({ data: data, ec: rsEncode(data, spec.ec) });
      }
    });
    var result = [];
    var maxData = 0;
    blocks.forEach(function (bl) { if (bl.data.length > maxData) maxData = bl.data.length; });
    for (var i = 0; i < maxData; i++) {
      blocks.forEach(function (bl) { if (i < bl.data.length) result.push(bl.data[i]); });
    }
    for (var i = 0; i < spec.ec; i++) {
      blocks.forEach(function (bl) { if (i < bl.ec.length) result.push(bl.ec[i]); });
    }
    return result;
  }

  // ---- Matrix ----
  function makeMatrix(version, finalCw) {
    var size = version * 4 + 17;
    var m = [], reserved = [];
    for (var r = 0; r < size; r++) {
      m.push(new Array(size).fill(null));
      reserved.push(new Array(size).fill(false));
    }
    function setF(r, c, val) { m[r][c] = val; reserved[r][c] = true; }

    // finder + separators
    function finder(r, c) {
      for (var dr = -1; dr <= 7; dr++) {
        for (var dc = -1; dc <= 7; dc++) {
          var rr = r + dr, cc = c + dc;
          if (rr < 0 || rr >= size || cc < 0 || cc >= size) continue;
          var on = (dr >= 0 && dr <= 6 && (dc === 0 || dc === 6)) ||
            (dc >= 0 && dc <= 6 && (dr === 0 || dr === 6)) ||
            (dr >= 2 && dr <= 4 && dc >= 2 && dc <= 4);
          setF(rr, cc, on ? 1 : 0);
        }
      }
    }
    finder(0, 0); finder(0, size - 7); finder(size - 7, 0);

    // timing
    for (var i = 8; i < size - 8; i++) {
      var v = i % 2 === 0 ? 1 : 0;
      if (m[6][i] === null) setF(6, i, v);
      if (m[i][6] === null) setF(i, 6, v);
    }

    // alignment
    var pos = ALIGN[version];
    for (var a = 0; a < pos.length; a++) {
      for (var b = 0; b < pos.length; b++) {
        var ar = pos[a], ac = pos[b];
        if (m[ar][ac] !== null) continue;
        for (var dr = -2; dr <= 2; dr++) {
          for (var dc = -2; dc <= 2; dc++) {
            var on = Math.max(Math.abs(dr), Math.abs(dc)) !== 1;
            setF(ar + dr, ac + dc, on ? 1 : 0);
          }
        }
      }
    }

    // dark module
    setF(size - 8, 8, 1);

    // reserve format info areas
    for (var i = 0; i < 9; i++) {
      if (m[8][i] === null) reserved[8][i] = true;
      if (m[i][8] === null) reserved[i][8] = true;
    }
    for (var i = 0; i < 8; i++) {
      if (m[8][size - 1 - i] === null) reserved[8][size - 1 - i] = true;
      if (m[size - 1 - i][8] === null) reserved[size - 1 - i][8] = true;
    }
    // reserve version info (v>=7)
    if (version >= 7) {
      for (var i = 0; i < 6; i++) {
        for (var j = 0; j < 3; j++) {
          reserved[i][size - 11 + j] = true;
          reserved[size - 11 + j][i] = true;
        }
      }
    }

    // place data (zigzag)
    var bitIdx = 0;
    var totalBits = finalCw.length * 8;
    function bitAt(idx) {
      var byte = finalCw[idx >> 3];
      return (byte >> (7 - (idx & 7))) & 1;
    }
    var col = size - 1;
    var upward = true;
    while (col > 0) {
      if (col === 6) col--; // skip timing column
      for (var rowStep = 0; rowStep < size; rowStep++) {
        var row = upward ? size - 1 - rowStep : rowStep;
        for (var c = 0; c < 2; c++) {
          var cc = col - c;
          if (reserved[row][cc]) continue;
          var bit = bitIdx < totalBits ? bitAt(bitIdx) : 0;
          bitIdx++;
          m[row][cc] = bit;
        }
      }
      col -= 2;
      upward = !upward;
    }

    return { m: m, reserved: reserved, size: size };
  }

  function penalty(m, size) {
    var score = 0;
    // rule 1: runs
    for (var r = 0; r < size; r++) {
      var runC = 1, runR = 1;
      for (var c = 1; c < size; c++) {
        if (m[r][c] === m[r][c - 1]) { runC++; if (runC === 5) score += 3; else if (runC > 5) score++; } else runC = 1;
        if (m[c][r] === m[c - 1][r]) { runR++; if (runR === 5) score += 3; else if (runR > 5) score++; } else runR = 1;
      }
    }
    // rule 2: 2x2 blocks
    for (var r = 0; r < size - 1; r++)
      for (var c = 0; c < size - 1; c++) {
        var v = m[r][c];
        if (v === m[r][c + 1] && v === m[r + 1][c] && v === m[r + 1][c + 1]) score += 3;
      }
    // rule 4: dark ratio
    var dark = 0;
    for (var r = 0; r < size; r++) for (var c = 0; c < size; c++) if (m[r][c]) dark++;
    var ratio = dark * 100 / (size * size);
    score += Math.floor(Math.abs(ratio - 50) / 5) * 10;
    return score;
  }

  function applyMaskAndFormat(base, size, version, maskPattern) {
    // clone data modules, apply mask on non-reserved
    var m = [];
    for (var r = 0; r < size; r++) m.push(base.m[r].slice());
    for (var r = 0; r < size; r++)
      for (var c = 0; c < size; c++)
        if (!base.reserved[r][c] && m[r][c] !== null && maskFn(maskPattern, r, c))
          m[r][c] ^= 1;

    // format info: EC level L = 1
    var fmt = bchTypeInfo((1 << 3) | maskPattern);
    placeFormat(m, size, fmt);

    if (version >= 7) placeVersion(m, size, version);
    return m;
  }

  function placeFormat(m, size, fmt) {
    // 15 bits. bit0 is LSB.
    for (var i = 0; i <= 5; i++) m[8][i] = (fmt >> i) & 1;
    m[8][7] = (fmt >> 6) & 1;
    m[8][8] = (fmt >> 7) & 1;
    m[7][8] = (fmt >> 8) & 1;
    for (var i = 9; i <= 14; i++) m[14 - i][8] = (fmt >> i) & 1;

    for (var i = 0; i <= 7; i++) m[size - 1 - i][8] = (fmt >> i) & 1;
    for (var i = 8; i <= 14; i++) m[8][size - 15 + i] = (fmt >> i) & 1;
    m[size - 8][8] = 1; // dark module stays
  }

  function placeVersion(m, size, version) {
    var bits = bchTypeNumber(version);
    for (var i = 0; i < 18; i++) {
      var b = (bits >> i) & 1;
      var r = Math.floor(i / 3), c = i % 3;
      m[r][size - 11 + c] = b;
      m[size - 11 + c][r] = b;
    }
  }

  function generate(text) {
    var version = chooseVersion(text);
    var enc = encodeData(text, version);
    var finalCw = buildFinalCodewords(enc.codewords, version);
    var base = makeMatrix(version, finalCw);

    var best = null, bestScore = Infinity;
    for (var p = 0; p < 8; p++) {
      var masked = applyMaskAndFormat(base, base.size, version, p);
      var s = penalty(masked, base.size);
      if (s < bestScore) { bestScore = s; best = masked; }
    }
    return { modules: best, size: base.size };
  }

  function toCanvas(text, sizePx) {
    var qr = generate(text);
    var quiet = 4;
    var count = qr.size + quiet * 2;
    var scale = Math.max(1, Math.floor((sizePx || 240) / count));
    var canvas = document.createElement('canvas');
    canvas.width = canvas.height = count * scale;
    var ctx = canvas.getContext('2d');
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#000000';
    for (var r = 0; r < qr.size; r++) {
      for (var c = 0; c < qr.size; c++) {
        if (qr.modules[r][c]) {
          ctx.fillRect((c + quiet) * scale, (r + quiet) * scale, scale, scale);
        }
      }
    }
    return canvas;
  }

  global.QRGen = {
    toCanvas: toCanvas,
    generate: generate,
    _internal: {
      VERSIONS: VERSIONS, ALIGN: ALIGN, maskFn: maskFn, bchTypeInfo: bchTypeInfo,
      chooseVersion: chooseVersion, encodeData: encodeData,
      buildFinalCodewords: buildFinalCodewords, makeMatrix: makeMatrix,
      dataCapacity: dataCapacity
    }
  };
})(window);