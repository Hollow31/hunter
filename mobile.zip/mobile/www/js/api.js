/**
 * API client + local storage layer for the Hunter mobile app.
 * All network calls go to a configurable backend base URL.
 */

/**
 * ⚙️ CONFIGURATION ÉDITEUR
 * Pour distribuer l'app "clé en main" (sans que l'utilisateur saisisse l'adresse
 * du serveur), renseignez ici l'URL de VOTRE serveur de production, par ex. :
 *   const PRODUCTION_SERVER = 'https://ma-chasse.fr';
 * Laissez la chaîne vide pour laisser l'utilisateur la configurer dans Réglages.
 */
const PRODUCTION_SERVER = '';

const Store = {
  KEY_API: 'hunter.apiBase',
  KEY_HUNTS: 'hunter.myHunts',
  KEY_SESSION: 'hunter.session',

  getApiBase() {
    if (PRODUCTION_SERVER) return PRODUCTION_SERVER.replace(/\/+$/, '');
    let base = localStorage.getItem(this.KEY_API) || '';
    if (!base) {
      // Web fallback: when the app is served from a real http(s) origin, use it.
      const o = location.origin;
      if (/^https?:/.test(o) && !/^https?:\/\/localhost/.test(o)) base = o;
    }
    return base.replace(/\/+$/, '');
  },
  setApiBase(url) {
    localStorage.setItem(this.KEY_API, (url || '').trim().replace(/\/+$/, ''));
  },
  isConfigured() {
    return !!this.getApiBase();
  },

  // Organizer: locally remembered hunts (with secret token)
  getMyHunts() {
    try { return JSON.parse(localStorage.getItem(this.KEY_HUNTS) || '[]'); }
    catch (e) { return []; }
  },
  saveMyHunt(hunt) {
    const hunts = this.getMyHunts().filter(h => h.huntId !== hunt.huntId);
    hunts.unshift(hunt);
    localStorage.setItem(this.KEY_HUNTS, JSON.stringify(hunts));
  },
  removeMyHunt(huntId) {
    localStorage.setItem(this.KEY_HUNTS,
      JSON.stringify(this.getMyHunts().filter(h => h.huntId !== huntId)));
  },

  // Player session
  getSession() {
    try { return JSON.parse(localStorage.getItem(this.KEY_SESSION) || 'null'); }
    catch (e) { return null; }
  },
  setSession(s) { localStorage.setItem(this.KEY_SESSION, JSON.stringify(s)); },
  clearSession() { localStorage.removeItem(this.KEY_SESSION); }
};

const Api = {
  async _fetch(path, options = {}) {
    const base = Store.getApiBase();
    if (!base) {
      const err = new Error('Serveur non configuré.');
      err.code = 'NO_SERVER';
      throw err;
    }
    let res;
    try {
      res = await fetch(base + path, {
        ...options,
        headers: { 'Content-Type': 'application/json', ...(options.headers || {}) }
      });
    } catch (e) {
      const err = new Error('Impossible de contacter le serveur.');
      err.code = 'NETWORK';
      throw err;
    }
    let data = null;
    try { data = await res.json(); } catch (e) { /* no body */ }
    if (!res.ok) {
      const err = new Error((data && data.error) || `Erreur ${res.status}`);
      err.status = res.status;
      throw err;
    }
    return data;
  },

  // --- Organizer ---
  createHunt(config) {
    return this._fetch('/api/hunts', { method: 'POST', body: JSON.stringify({ config }) });
  },
  getHunt(huntId, token) {
    return this._fetch(`/api/hunts/${huntId}`, { headers: { 'X-Organizer-Token': token } });
  },
  updateHunt(huntId, token, config) {
    return this._fetch(`/api/hunts/${huntId}`, {
      method: 'PUT', headers: { 'X-Organizer-Token': token }, body: JSON.stringify({ config })
    });
  },
  deleteHunt(huntId, token) {
    return this._fetch(`/api/hunts/${huntId}`, { method: 'DELETE', headers: { 'X-Organizer-Token': token } });
  },
  getTeams(huntId, token) {
    return this._fetch(`/api/hunts/${huntId}/teams`, { headers: { 'X-Organizer-Token': token } });
  },
  deleteTeam(huntId, token, teamId) {
    return this._fetch(`/api/hunts/${huntId}/teams/${teamId}`, {
      method: 'DELETE', headers: { 'X-Organizer-Token': token }
    });
  },

  // --- Player ---
  resolveCode(code) {
    return this._fetch(`/api/hunts/code/${encodeURIComponent(code)}`);
  },
  join(huntId, name, members) {
    return this._fetch(`/api/hunts/${huntId}/join`, {
      method: 'POST', body: JSON.stringify({ name, members })
    });
  },
  getSteps(huntId, teamId) {
    return this._fetch(`/api/play/${huntId}/${teamId}/steps`);
  },
  getStep(huntId, teamId, n) {
    return this._fetch(`/api/play/${huntId}/${teamId}/step/${n}`);
  },
  submitAnswer(huntId, teamId, n, answer) {
    return this._fetch(`/api/play/${huntId}/${teamId}/step/${n}/answer`, {
      method: 'POST', body: JSON.stringify({ answer })
    });
  },
  getFinal(huntId, teamId) {
    return this._fetch(`/api/play/${huntId}/${teamId}/final`);
  },
  uploadPhoto(huntId, teamId, n, photoBase64, mimeType) {
    return this._fetch(`/api/upload/${huntId}/${teamId}/${n}`, {
      method: 'POST', body: JSON.stringify({ photo: photoBase64, mimeType })
    });
  },

  photoUrl(path) {
    return Store.getApiBase() + path;
  }
};
