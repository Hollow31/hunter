/**
 * App shell: navigation, home screen, settings, shared helpers,
 * and (optional) Capacitor native bridges for Share / QR scan / deep links.
 */
const App = {
  root: null,

  init() {
    this.root = document.getElementById('app');
    this.setupNativeBridges();
    this.handleDeepLink(location.href);
    this.route();
    window.addEventListener('hashchange', () => this.route());
  },

  // ---- Navigation ----
  go(hash) { location.hash = hash; },
  route() {
    const hash = location.hash.replace(/^#/, '') || 'home';
    const [screen, ...rest] = hash.split('/');
    const arg = rest.join('/');
    switch (screen) {
      case 'home': return this.renderHome();
      case 'settings': return this.renderSettings();
      case 'organizer': return Organizer.render(arg);
      case 'play': return Player.render(arg);
      default: return this.renderHome();
    }
  },

  setScreen(html, opts = {}) {
    this.root.innerHTML = html;
    this.root.scrollTop = 0;
    if (opts.onMount) opts.onMount();
  },

  // ---- Home ----
  renderHome() {
    this.applyTheme(null);
    const configured = Store.isConfigured();
    const myHunts = Store.getMyHunts();
    const session = Store.getSession();

    this.setScreen(`
      <div class="screen home">
        <button class="icon-btn settings-gear" data-act="settings" aria-label="Réglages">⚙️</button>
        <div class="hero">
          <div class="hero-logo">🗺️</div>
          <h1>Chasse au Trésor</h1>
          <p class="tagline">Créez, partagez, jouez.</p>
        </div>

        ${!configured ? `
          <div class="banner warn">
            <strong>Serveur non configuré.</strong>
            <p>Renseignez l'adresse du serveur pour commencer.</p>
            <button class="btn small" data-act="settings">Configurer</button>
          </div>` : ''}

        <div class="home-actions">
          <button class="big-card create" data-act="create" ${!configured ? 'disabled' : ''}>
            <span class="bc-icon">🛠️</span>
            <span class="bc-title">Créer une chasse</span>
            <span class="bc-sub">Configurez vos énigmes et partagez</span>
          </button>
          <button class="big-card join" data-act="join" ${!configured ? 'disabled' : ''}>
            <span class="bc-icon">🎯</span>
            <span class="bc-title">Rejoindre une chasse</span>
            <span class="bc-sub">Scannez un QR ou entrez un code</span>
          </button>
        </div>

        ${session ? `
          <div class="resume-card" data-act="resume">
            <span>▶️ Reprendre : <strong>${this.esc(session.teamName || 'ma partie')}</strong></span>
          </div>` : ''}

        ${myHunts.length ? `
          <div class="section">
            <h3>Mes chasses créées</h3>
            <div class="my-hunts">
              ${myHunts.map(h => `
                <button class="hunt-row" data-hunt="${h.huntId}">
                  <span class="hr-title">${this.esc(h.title || 'Chasse')}</span>
                  <span class="hr-code">Code ${this.esc(h.joinCode)}</span>
                </button>`).join('')}
            </div>
          </div>` : ''}
      </div>
    `, {
      onMount: () => {
        this.root.querySelectorAll('[data-act]').forEach(el => {
          el.addEventListener('click', () => {
            const act = el.getAttribute('data-act');
            if (act === 'settings') this.go('settings');
            if (act === 'create') Organizer.createNew();
            if (act === 'join') this.go('play/join');
            if (act === 'resume' && session) this.go(`play/hub`);
          });
        });
        this.root.querySelectorAll('[data-hunt]').forEach(el => {
          el.addEventListener('click', () => this.go(`organizer/${el.getAttribute('data-hunt')}`));
        });
      }
    });
  },

  // ---- Settings ----
  renderSettings() {
    const current = localStorage.getItem(Store.KEY_API) || '';
    this.setScreen(`
      <div class="screen">
        ${this.header('Réglages', 'home')}
        <div class="form">
          <label>Adresse du serveur</label>
          <input type="url" id="apiBase" placeholder="https://mon-serveur.fr" value="${this.esc(current)}" autocapitalize="off" autocorrect="off" spellcheck="false">
          <p class="hint">Adresse fournie par l'organisateur / votre hébergement.
          Exemple : <code>https://ma-chasse.fr</code></p>
          <button class="btn primary" id="saveApi">Enregistrer</button>
          <button class="btn ghost" id="testApi">Tester la connexion</button>
          <div id="testResult" class="test-result"></div>
        </div>
      </div>
    `, {
      onMount: () => {
        this.bindBack('home');
        document.getElementById('saveApi').addEventListener('click', () => {
          Store.setApiBase(document.getElementById('apiBase').value);
          this.toast('Serveur enregistré ✓');
          this.go('home');
        });
        document.getElementById('testApi').addEventListener('click', async () => {
          const url = document.getElementById('apiBase').value.trim().replace(/\/+$/, '');
          const box = document.getElementById('testResult');
          box.textContent = 'Test en cours…';
          try {
            const r = await fetch(url + '/health');
            const j = await r.json();
            box.className = 'test-result ok';
            box.textContent = j.status === 'ok' ? 'Connexion réussie ✓' : 'Réponse inattendue.';
          } catch (e) {
            box.className = 'test-result err';
            box.textContent = 'Échec : serveur injoignable.';
          }
        });
      }
    });
  },

  // ---- Shared UI helpers ----
  header(title, backHash) {
    return `
      <div class="topbar">
        <button class="icon-btn" data-back aria-label="Retour">←</button>
        <h2>${this.esc(title)}</h2>
        <span class="spacer"></span>
      </div>`;
  },
  bindBack(backHash) {
    const b = this.root.querySelector('[data-back]');
    if (b) b.addEventListener('click', () => this.go(backHash));
  },

  esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  },
  nl2br(s) { return this.esc(s).replace(/\n/g, '<br>'); },

  toast(msg, type = '') {
    let t = document.getElementById('toast');
    if (!t) {
      t = document.createElement('div');
      t.id = 'toast';
      document.body.appendChild(t);
    }
    t.className = 'toast show ' + type;
    t.textContent = msg;
    clearTimeout(this._toastTimer);
    this._toastTimer = setTimeout(() => { t.className = 'toast'; }, 2600);
  },

  applyTheme(theme) {
    const root = document.documentElement;
    const t = theme || {};
    root.style.setProperty('--primary', t.primaryColor || '#e67e22');
    root.style.setProperty('--secondary', t.secondaryColor || '#2c3e50');
    root.style.setProperty('--accent', t.accentColor || '#27ae60');
  },

  async handleError(e) {
    if (e && e.code === 'NO_SERVER') {
      this.toast('Configurez d\'abord le serveur.', 'err');
      this.go('settings');
      return;
    }
    this.toast((e && e.message) || 'Une erreur est survenue.', 'err');
  },

  // ---- Native bridges (Capacitor) with web fallbacks ----
  setupNativeBridges() {
    this.cap = window.Capacitor || null;
    this.isNative = !!(this.cap && this.cap.isNativePlatform && this.cap.isNativePlatform());
  },

  async share(text, title) {
    // Try Capacitor Share, then Web Share API, then clipboard.
    try {
      if (this.cap && this.cap.Plugins && this.cap.Plugins.Share) {
        await this.cap.Plugins.Share.share({ title: title || 'Chasse au Trésor', text });
        return;
      }
    } catch (e) { /* fallthrough */ }
    if (navigator.share) {
      try { await navigator.share({ title: title || 'Chasse au Trésor', text }); return; }
      catch (e) { if (e && e.name === 'AbortError') return; }
    }
    try {
      await navigator.clipboard.writeText(text);
      this.toast('Copié dans le presse-papier ✓');
    } catch (e) {
      this.toast('Partage non disponible.', 'err');
    }
  },

  async copy(text) {
    try { await navigator.clipboard.writeText(text); this.toast('Copié ✓'); }
    catch (e) { this.toast('Copie impossible.', 'err'); }
  },

  /**
   * Scan a QR code. Uses the Capacitor barcode scanner plugin when available.
   * Returns the decoded string, or null if unavailable / cancelled.
   */
  async scanQr() {
    const P = this.cap && this.cap.Plugins;
    try {
      if (P && P.BarcodeScanner && P.BarcodeScanner.scan) {
        const res = await P.BarcodeScanner.scan({ formats: ['QR_CODE'] });
        if (res && res.barcodes && res.barcodes.length) return res.barcodes[0].rawValue;
        if (res && res.ScanResult) return res.ScanResult;
        return null;
      }
    } catch (e) { /* fallthrough */ }
    this.toast('Scanner indisponible : saisissez le code.', 'err');
    return null;
  },

  handleDeepLink(url) {
    try {
      const u = new URL(url);
      const code = u.searchParams.get('j') || u.searchParams.get('join') || u.searchParams.get('code');
      if (code) {
        sessionStorage.setItem('hunter.pendingCode', code.toUpperCase());
        location.hash = 'play/join';
      }
    } catch (e) { /* ignore */ }
  }
};

document.addEventListener('DOMContentLoaded', () => App.init());

// Capacitor App plugin deep-link listener (native)
document.addEventListener('deviceready', () => {}, false);
if (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.App) {
  window.Capacitor.Plugins.App.addListener('appUrlOpen', (data) => {
    if (data && data.url) { App.handleDeepLink(data.url); App.route(); }
  });
}
