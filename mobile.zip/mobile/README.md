# 🗺️ Chasse au Trésor — Application mobile (Android & iOS)

Version **mobile** de l'application de chasse au trésor. Contrairement à la version web
(dossier `../backend` + `../frontend`), cette version est pensée pour être **publiée sur les
stores** avec le modèle suivant :

> **Une seule personne achète l'application.** Elle configure entièrement sa chasse au trésor
> depuis son téléphone, puis la partage via un **QR code**, un **code court** ou un **lien**.
> Les joueurs rejoignent en scannant le QR, en saisissant le code ou en ouvrant le lien.

Ce dossier est **totalement indépendant** : il ne modifie pas la version web existante.

---

## 📁 Contenu

```
mobile/
├── capacitor.config.json     # Configuration de l'app native (Capacitor)
├── package.json              # Dépendances Capacitor + scripts
├── www/                      # L'application (HTML/CSS/JS) empaquetée dans l'app
│   ├── index.html
│   ├── css/style.css
│   └── js/
│       ├── qr.js             # Générateur de QR code (hors-ligne, sans dépendance)
│       ├── api.js            # Client API + stockage local
│       ├── app.js            # Navigation, accueil, réglages, ponts natifs
│       ├── organizer.js      # Mode organisateur (édition + partage + suivi)
│       └── player.js         # Mode joueur (rejoindre + jouer)
├── server/                   # Backend multi-chasses (Node.js/Express)
│   ├── server.js
│   ├── lib/                  # data, codes, validators
│   └── routes/               # hunts, play, upload
└── docs/
    ├── GUIDE_UTILISATEUR.md  # Comment utiliser l'app (organisateur + joueurs)
    └── DEPLOIEMENT_STORES.md # Publier sur Google Play et l'App Store
```

---

## 🧩 Architecture en bref

- **L'app mobile** (dossier `www/`) est une petite application web empaquetée en application
  native grâce à **[Capacitor](https://capacitorjs.com)**. Le même code tourne sur **Android**
  et **iOS**, et peut aussi s'ouvrir dans un navigateur (lien de partage).
- **Le serveur** (`server/`) héberge les chasses. Chaque chasse possède :
  - un identifiant privé + un **jeton organisateur** (secret, stocké uniquement sur le téléphone
    de l'organisateur) ;
  - un **code de partage** court (ex. `H7K9P2`) que les joueurs utilisent pour rejoindre.
- L'app se connecte au serveur via une **URL configurable** (écran Réglages).

```mermaid
flowchart LR
  O[📱 Organisateur] -- crée / configure --> S[(🖥️ Serveur)]
  S -- QR / code / lien --> J1[📱 Joueur 1]
  S -- QR / code / lien --> J2[📱 Joueur 2]
  J1 -- réponses --> S
  J2 -- réponses --> S
  O -- suivi en direct --> S
```

---

## 🚀 Démarrage rapide (développeur)

### 1. Lancer le serveur

```bash
cd mobile/server
npm install
npm start          # écoute sur http://localhost:3000
```

> Voir `docs/DEPLOIEMENT_STORES.md` pour héberger le serveur en production.

### 2. Tester l'app dans un navigateur

Ouvrez `http://localhost:3000` — le serveur sert aussi l'app web (`www/`).
Dans **Réglages**, mettez l'URL du serveur (`http://localhost:3000`) puis créez une chasse.

### 3. Générer les applications natives

```bash
cd mobile
npm install
npx cap add android      # nécessite Android Studio
npx cap add ios          # nécessite un Mac + Xcode
npm run sync             # copie www/ dans les projets natifs
npm run open:android     # ouvre Android Studio
npm run open:ios         # ouvre Xcode
```

Puis compilez/lancez depuis Android Studio ou Xcode.
La procédure complète de **publication sur les stores** est décrite dans
[`docs/DEPLOIEMENT_STORES.md`](docs/DEPLOIEMENT_STORES.md).

---

## 📖 Documentation

| Document | Pour qui | Contenu |
|---|---|---|
| [`docs/GUIDE_UTILISATEUR.md`](docs/GUIDE_UTILISATEUR.md) | Organisateur & joueurs | Utiliser l'app pas à pas, tous les types d'énigmes |
| [`docs/DEPLOIEMENT_STORES.md`](docs/DEPLOIEMENT_STORES.md) | Éditeur / développeur | Héberger le serveur, publier sur Google Play & App Store |

---

## ✅ Types d'énigmes disponibles

Réponse libre · Énigme · Code secret · Réponses multiples · QCM · Associations ·
Remise en ordre · Questions multiples · Envoi de photo.

---

## 🔒 Sécurité

- Le **jeton organisateur** ne quitte jamais le téléphone de l'organisateur ; il est requis
  pour modifier une chasse ou voir le suivi des équipes.
- Les **réponses** ne sont jamais envoyées aux joueurs : la validation se fait côté serveur.
- Les entrées sont **validées et bornées** côté serveur (`server/routes/hunts.js`).
- Pensez à servir le serveur en **HTTPS** en production (voir doc de déploiement).
