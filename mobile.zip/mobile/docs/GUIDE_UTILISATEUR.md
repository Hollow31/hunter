# 📖 Guide d'utilisation — Chasse au Trésor

Ce guide explique **comment utiliser l'application**, sans connaissances techniques.
Il y a deux rôles :

- 🛠️ **L'organisateur** : la personne qui a acheté l'application, crée la chasse et la partage.
- 🎯 **Les joueurs** : les personnes (équipes) qui participent.

> 💡 **En résumé** : l'organisateur crée une chasse → obtient un **QR code / un code / un lien**
> → les joueurs le scannent ou le saisissent → tout le monde joue !

---

## 1. Première ouverture (à faire une seule fois)

À la première ouverture, l'application demande **l'adresse du serveur**.

1. Ouvrez l'écran **Réglages** (roue dentée ⚙️ en haut à droite de l'accueil).
2. Saisissez l'adresse fournie avec votre application, par exemple :
   `https://ma-chasse.fr`
3. Appuyez sur **Tester la connexion** → vous devez voir « Connexion réussie ✓ ».
4. Appuyez sur **Enregistrer**.

> ℹ️ Cette adresse est l'endroit où sont stockées les chasses. Elle est donnée par la personne
> qui héberge le serveur (voir le document de déploiement). Une fois renseignée, vous n'avez
> plus besoin d'y revenir.

---

## 2. 🛠️ Côté organisateur — créer une chasse

### Étape 1 — Créer

1. Sur l'accueil, appuyez sur **« Créer une chasse »**.
2. Une nouvelle chasse vierge est créée et s'ouvre dans l'éditeur.
   Elle possède déjà un **code de partage** (visible dans l'onglet *Partager*).

### Étape 2 — Configuration générale

Dans l'onglet **Configuration** :

| Champ | À quoi ça sert |
|---|---|
| **Titre** | Le nom de votre chasse (ex. « La Grande Chasse ») |
| **Sous-titre** | Une phrase d'accroche affichée aux joueurs |
| **Message de fin** | Le texte affiché quand une équipe termine (indice final, félicitations…) |
| **Image de fin** | (Optionnel) Adresse d'une image montrée à la victoire |
| **Couleurs 1/2/3** | Personnalisez l'apparence (aperçu en direct) |

Appuyez sur **💾 Enregistrer** pour sauvegarder.

### Étape 3 — Ajouter des étapes (les énigmes)

Dans l'onglet **Étapes** :

1. Appuyez sur **« ＋ Ajouter une étape »**.
2. Donnez un **titre**, choisissez un **type d'épreuve**, écrivez l'**énoncé**.
3. (Optionnel) ajoutez une **image** (adresse web) et un **indice**
   (révélé automatiquement aux joueurs après 3 mauvaises tentatives).
4. Remplissez les champs propres au type choisi (voir tableau ci-dessous).
5. Appuyez sur **Valider**.

Vous pouvez **réordonner** les étapes (▲ ▼), les **modifier** (✏️) ou les **supprimer** (🗑️).

#### Les types d'épreuves

| Type | Ce que fait le joueur | Ce que vous configurez |
|---|---|---|
| **Réponse libre** | Écrit un mot / une phrase | La ou les réponses acceptées (accents et majuscules ignorés) |
| **Énigme** | Idem, présenté comme une devinette | Les réponses acceptées |
| **Code secret** | Saisit un code | Le ou les codes valides |
| **Réponses multiples** | Remplit plusieurs champs | Toutes les réponses attendues (l'ordre n'a pas d'importance) |
| **QCM** | Coche une ou plusieurs cases | La liste des choix + la/les bonne(s) réponse(s) |
| **Associations** | Relie gauche ↔ droite | Les paires correctes |
| **Remise en ordre** | Réordonne des éléments | Les éléments **dans le bon ordre** |
| **Questions multiples** | Répond à plusieurs sous-questions | Chaque question + ses réponses |
| **Photo** | Envoie une photo | Rien (l'envoi de la photo valide l'étape) |

> 💡 **Astuce** : pour la « Réponse libre », ajoutez plusieurs variantes
> (ex. `Adeline`, `adeline`, `Adeline is coming`) pour accepter les différentes orthographes.

### Étape 4 — Partager la chasse

Dans l'onglet **Partager**, trois moyens sont proposés :

1. 📷 **QR code** — les joueurs le scannent depuis l'écran « Rejoindre ».
2. 🔤 **Code court** (ex. `H7K9P2`) — à dicter ou afficher.
3. 🔗 **Lien** — à envoyer par SMS, WhatsApp, e-mail…

Le bouton **« 📤 Partager le lien »** ouvre le partage natif du téléphone.

> ⚠️ Il faut avoir ajouté **au moins une étape** pour pouvoir partager.

### Étape 5 — Suivre les équipes en direct

Dans l'onglet **Suivi** :

- La liste des équipes qui ont rejoint,
- leur **progression** (barre + pastilles),
- un 🏁 quand une équipe a terminé.

Appuyez sur **↻ Rafraîchir** pour mettre à jour. Vous pouvez aussi supprimer une équipe.

### Retrouver ses chasses

Vos chasses créées apparaissent sur l'**accueil**, sous « Mes chasses créées ».
Appuyez dessus pour rouvrir l'éditeur, re-partager ou suivre les équipes.

> 🔐 Les informations secrètes de vos chasses (jeton d'organisateur) sont stockées
> **uniquement sur votre téléphone**. Ne désinstallez pas l'app si vous voulez garder la main
> sur une chasse en cours.

---

## 3. 🎯 Côté joueur — rejoindre et jouer

### Rejoindre

1. Sur l'accueil, appuyez sur **« Rejoindre une chasse »**.
2. Deux possibilités :
   - **📷 Scanner un QR code** (montré par l'organisateur), **ou**
   - **saisir le code** (ex. `H7K9P2`).
   - *(Si vous avez reçu un lien, il ouvre directement cette étape avec le code pré-rempli.)*
3. La chasse est trouvée : choisissez un **nom d'équipe** et appuyez sur **« C'est parti ! »**.

### Jouer

- Vous arrivez sur le **tableau des étapes**. Chaque case est une énigme.
- Appuyez sur une étape, lisez l'énoncé, répondez, puis **Validez**.
- ✅ Une étape réussie devient verte. ❌ En cas d'erreur, réessayez
  (un indice apparaît après 3 essais si l'organisateur en a prévu un).
- Quand **toutes** les étapes sont validées, le bouton **« 🏆 Voir le trésor »** apparaît :
  il affiche le message de fin de l'organisateur.

> 💾 La progression est **sauvegardée sur le serveur**. Si vous fermez l'app, vous pouvez
> reprendre via **« Reprendre »** sur l'accueil.

---

## 4. Questions fréquentes

**Faut-il qu'un joueur achète l'application ?**
Non. **Une seule personne** (l'organisateur) a besoin de l'application payante pour créer la
chasse. Les joueurs peuvent utiliser l'application (gratuite pour rejoindre) **ou** simplement
ouvrir le **lien** dans leur navigateur.

**Combien d'équipes peuvent jouer ?**
Autant que vous voulez — chaque équipe choisit un nom différent.

**Peut-on jouer sans réseau ?**
Non : l'app a besoin d'Internet pour communiquer avec le serveur (rejoindre, valider, suivre).

**J'ai perdu le code / le QR.**
L'organisateur les retrouve à tout moment dans l'onglet **Partager** de sa chasse.

**Comment recommencer une chasse ?**
Créez une nouvelle équipe (nouveau nom) — chaque équipe a sa propre progression.
L'organisateur peut aussi supprimer des équipes depuis l'onglet **Suivi**.

**Peut-on modifier une chasse après l'avoir partagée ?**
Oui, à tout moment via l'éditeur. Le **code de partage reste le même**.
