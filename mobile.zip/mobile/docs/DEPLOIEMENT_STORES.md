# 🚀 Déploiement — Serveur + Publication sur les stores

Ce document explique comment **héberger le serveur** puis **publier l'application** sur le
**Google Play Store** (Android) et l'**App Store** (iOS).

Il s'adresse à la personne qui édite/publie l'application (le développeur ou l'éditeur).

---

## Sommaire

1. [Prérequis](#1-prérequis)
2. [Héberger le serveur (backend)](#2-héberger-le-serveur-backend)
3. [Configurer l'identité de l'app](#3-configurer-lidentité-de-lapp)
4. [Icônes, splash screen et permissions](#4-icônes-splash-screen-et-permissions)
5. [Liens de partage (deep links)](#5-liens-de-partage-deep-links)
6. [Générer les projets natifs (Capacitor)](#6-générer-les-projets-natifs-capacitor)
7. [Publier sur Google Play (Android)](#7-publier-sur-google-play-android)
8. [Publier sur l'App Store (iOS)](#8-publier-sur-lapp-store-ios)
9. [Modèle « un seul acheteur »](#9-modèle-un-seul-acheteur)
10. [Checklist finale](#10-checklist-finale)

---

## 1. Prérequis

| Outil | Pour quoi | Remarque |
|---|---|---|
| **Node.js 18+** | Serveur + Capacitor | https://nodejs.org |
| **Android Studio** | Build Android | Windows / macOS / Linux |
| **Xcode 15+** | Build iOS | **macOS obligatoire** |
| **Compte Google Play Console** | Publier sur Android | 25 $ une fois |
| **Compte Apple Developer** | Publier sur iOS | 99 $ / an |
| **Un serveur ou un hébergement** | Héberger le backend | VPS, Render, Railway, Fly.io… |

---

## 2. Héberger le serveur (backend)

L'app a besoin d'un serveur accessible en **HTTPS** depuis Internet. Le code est dans
`mobile/server/`.

### Option A — VPS Debian/Ubuntu (systemd + nginx)

```bash
# Sur le serveur
sudo apt update && sudo apt install -y nodejs npm nginx
git clone <votre-repo> ~/hunter
cd ~/hunter/mobile/server
npm install --omit=dev

# Lancer via systemd
sudo tee /etc/systemd/system/hunter-mobile.service >/dev/null <<'EOF'
[Unit]
Description=Hunter mobile server
After=network.target

[Service]
WorkingDirectory=/root/hunter/mobile/server
ExecStart=/usr/bin/node server.js
Restart=always
Environment=PORT=3000

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl enable --now hunter-mobile
```

Reverse proxy nginx + HTTPS (Let's Encrypt) :

```nginx
server {
  server_name ma-chasse.fr;
  location / { proxy_pass http://127.0.0.1:3000; proxy_set_header Host $host; }
}
```

```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d ma-chasse.fr
```

Votre serveur est maintenant sur **`https://ma-chasse.fr`**.

### Option B — Plateforme managée (Render / Railway / Fly.io)

1. Poussez le dépôt sur GitHub.
2. Créez un service Web pointant sur `mobile/server`.
3. Commande de démarrage : `node server.js` — Port : `3000` (ou variable `PORT`).
4. Vous obtenez une URL HTTPS (ex. `https://ma-chasse.onrender.com`).

> ⚠️ **Persistance des données** : les chasses/équipes sont stockées dans
> `server/data/hunts.json` et les photos dans `server/uploads/`. Sur les plateformes à
> disque éphémère, montez un **volume persistant** sur ces dossiers, sinon les données
> sont perdues au redéploiement.

### Vérifier

```bash
curl https://ma-chasse.fr/health      # -> {"status":"ok"}
```

> 📌 **Important** : notez cette URL. C'est elle que les utilisateurs saisissent dans
> **Réglages**. Pour éviter cette saisie, vous pouvez la coder en dur (voir
> [section 9](#9-modèle-un-seul-acheteur)).

---

## 3. Configurer l'identité de l'app

Éditez `mobile/capacitor.config.json` :

```json
{
  "appId": "com.votresociete.chasseautresor",
  "appName": "Chasse au Trésor",
  "webDir": "www"
}
```

- **`appId`** : identifiant unique inversé (ex. `com.votresociete.chasseautresor`).
  Il ne pourra **plus être changé** après publication. Utilisez votre propre domaine.
- **`appName`** : le nom affiché sous l'icône.

La **version** se gère ensuite dans les projets natifs :
- Android : `android/app/build.gradle` → `versionCode` (entier, à incrémenter) et `versionName`.
- iOS : dans Xcode → onglet *General* → *Version* et *Build*.

---

## 4. Icônes, splash screen et permissions

### Icônes & splash

Le plus simple : le plugin officiel **@capacitor/assets**.

```bash
cd mobile
npm install -D @capacitor/assets
# Placez une image 1024x1024 dans  assets/icon.png
# et (optionnel) assets/splash.png (2732x2732)
npx capacitor-assets generate
```

### Permissions à déclarer

L'app utilise l'**appareil photo** (scan de QR + envoi de photo).

**Android** — `android/app/src/main/AndroidManifest.xml` :
```xml
<uses-permission android:name="android.permission.CAMERA" />
<uses-permission android:name="android.permission.INTERNET" />
```

**iOS** — `ios/App/App/Info.plist` :
```xml
<key>NSCameraUsageDescription</key>
<string>L'application utilise l'appareil photo pour scanner les QR codes et envoyer des photos d'énigme.</string>
<key>NSPhotoLibraryUsageDescription</key>
<string>L'application accède à vos photos pour valider certaines énigmes.</string>
```

---

## 5. Liens de partage (deep links)

Le partage produit un lien du type `https://ma-chasse.fr/?j=H7K9P2`.
Pour que ce lien **ouvre l'application** (et pas seulement le navigateur), configurez les
liens universels/app links. C'est **optionnel** : sans configuration, le lien ouvre l'app web
dans le navigateur, ce qui fonctionne aussi.

Le plugin `@capacitor/app` écoute déjà l'événement `appUrlOpen` (voir `www/js/app.js`).

- **Android (App Links)** : ajoutez un `intent-filter` sur votre domaine dans
  `AndroidManifest.xml`, et hébergez `/.well-known/assetlinks.json` sur `ma-chasse.fr`.
- **iOS (Universal Links)** : activez *Associated Domains* (`applinks:ma-chasse.fr`) dans Xcode
  et hébergez `/.well-known/apple-app-site-association`.

> Détails officiels : https://capacitorjs.com/docs/guides/deep-links

---

## 6. Générer les projets natifs (Capacitor)

```bash
cd mobile
npm install
npx cap add android        # crée le dossier android/
npx cap add ios            # crée le dossier ios/ (macOS)
npm run sync               # = cap sync : copie www/ + installe les plugins natifs
```

À **chaque modification** de `www/`, relancez :
```bash
npm run sync
```

Ouvrir les IDE :
```bash
npm run open:android       # Android Studio
npm run open:ios           # Xcode
```

---

## 7. Publier sur Google Play (Android)

### a. Créer une clé de signature (une seule fois)

```bash
keytool -genkey -v -keystore hunter-release.keystore \
  -alias hunter -keyalg RSA -keysize 2048 -validity 10000
```
> Conservez ce fichier **précieusement** : il est indispensable pour toutes les mises à jour.

### b. Configurer la signature

Dans `android/app/build.gradle`, ajoutez un `signingConfigs.release` pointant vers votre
keystore (voir la doc Android *"Sign your app"*), puis référencez-le dans `buildTypes.release`.

### c. Générer le bundle

Android Studio → **Build → Generate Signed Bundle / APK → Android App Bundle (.aab)**.
Ou en ligne de commande :
```bash
cd android && ./gradlew bundleRelease
# sortie : android/app/build/outputs/bundle/release/app-release.aab
```

### d. Play Console

1. https://play.google.com/console → **Créer une application**.
2. Renseignez la fiche : nom, description, **captures d'écran** (min. 2), icône 512×512,
   image de bannière 1024×500.
3. **Politique de confidentialité** (URL obligatoire) et questionnaire *Data safety*.
4. Créez une **release de production**, importez le `.aab`.
5. Prix : gratuit ou **payant** (voir [section 9](#9-modèle-un-seul-acheteur)).
6. Envoyez en revue. Délai habituel : quelques heures à quelques jours.

---

## 8. Publier sur l'App Store (iOS)

> Nécessite un **Mac** avec Xcode et un compte **Apple Developer**.

### a. Signature

Xcode → cible **App** → *Signing & Capabilities* → sélectionnez votre **Team**.
Xcode gère automatiquement les certificats et profils.

### b. Archive

1. Sélectionnez **Any iOS Device (arm64)**.
2. Menu **Product → Archive**.
3. Dans l'Organizer : **Distribute App → App Store Connect → Upload**.

### c. App Store Connect

1. https://appstoreconnect.apple.com → **Mes apps → +** → nouvelle app (choisissez le `appId`).
2. Fiche : nom, description, mots-clés, **captures d'écran** par taille d'écran, icône 1024×1024.
3. **Politique de confidentialité** (URL) + section *App Privacy*.
4. Sélectionnez le build uploadé.
5. Prix (gratuit ou payant), puis **Envoyer pour examen**.

> 💡 Testez d'abord via **TestFlight** avant la publication publique.

### Éviter un rejet Apple

- Fournissez une **description de permission caméra** claire (section 4).
- L'app doit être **fonctionnelle sans compte** : donnez à Apple, dans les notes de revue,
  un **serveur de démo** et un **code de chasse** de test pour qu'ils puissent essayer.
- Pas de code exécutable téléchargé à distance (le générateur de QR est embarqué, ✅).

---

## 9. Modèle « un seul acheteur »

L'objectif : **une seule personne achète**, configure la chasse, puis partage ; les joueurs
rejoignent gratuitement.

Deux stratégies possibles :

### Stratégie 1 — Application payante unique (la plus simple)

- Publiez l'app en **payante** sur les stores.
- L'acheteur l'installe, crée sa chasse, partage le **lien**.
- Les joueurs ouvrent le **lien** dans leur navigateur (l'app web est servie par le serveur) —
  **aucun achat requis** pour jouer.
- ✅ Simple. ❌ Les joueurs jouent dans le navigateur, pas dans l'app native.

### Stratégie 2 — App gratuite + achat intégré « Organisateur »

- Publiez l'app **gratuite** : tout le monde peut l'installer et **rejoindre**.
- La fonction **« Créer une chasse »** est débloquée par un **achat intégré** (in-app purchase)
  non-consommable.
- Techniquement : ajoutez le plugin de facturation
  (ex. [`@capacitor-community/in-app-purchases`](https://github.com/capacitor-community/in-app-purchases))
  et conditionnez le bouton *Créer* dans `www/js/app.js` (`renderHome`, action `create`) à la
  possession de l'achat.
- ✅ Joueurs et organisateur dans la même app native. ❌ Un peu plus de configuration store.

### Fixer l'URL du serveur (recommandé pour la distribution grand public)

Pour éviter que l'utilisateur saisisse l'adresse du serveur, codez-la en dur.
Dans `www/js/api.js`, renseignez la constante prévue à cet effet, tout en haut du fichier :

```js
const PRODUCTION_SERVER = 'https://ma-chasse.fr';   // URL fixe de votre serveur
```

Laissée vide, l'utilisateur configure l'adresse dans **Réglages**. Renseignée, l'écran
Réglages devient facultatif et l'app est utilisable immédiatement après installation.

---

## 10. Checklist finale

- [ ] Serveur en ligne, HTTPS, `GET /health` renvoie `ok`
- [ ] Données persistées (volume monté sur `server/data` et `server/uploads`)
- [ ] `appId` définitif et `appName` corrects dans `capacitor.config.json`
- [ ] Icône 1024×1024 + splash générés
- [ ] Permissions caméra déclarées (Android + iOS) avec descriptions
- [ ] URL du serveur fixée (ou écran Réglages documenté pour l'acheteur)
- [ ] `npm run sync` effectué après le dernier changement de `www/`
- [ ] Android : keystore sauvegardé, `.aab` signé généré
- [ ] iOS : archive uploadée, testée via TestFlight
- [ ] Fiches store : captures, description, politique de confidentialité
- [ ] Modèle de monétisation choisi (payant unique ou achat intégré)
- [ ] Compte de démo / code de test fourni aux équipes de revue
