const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');
const fs = require('fs');

const huntsRouter = require('./routes/hunts');
const playRouter = require('./routes/play');
const uploadRouter = require('./routes/upload');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(helmet({ contentSecurityPolicy: false, crossOriginEmbedderPolicy: false }));
app.use(cors());

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 300,
  standardHeaders: true,
  legacyHeaders: false
});
app.use('/api/', limiter);

// Larger limit to accept base64 photo uploads.
app.use(express.json({ limit: '15mb' }));

// Serve the mobile web app (also used as web fallback / QR landing page).
app.use(express.static(path.join(__dirname, '..', 'www')));

// Ensure data & uploads directories exist.
for (const dir of ['data', 'uploads']) {
  const full = path.join(__dirname, dir);
  if (!fs.existsSync(full)) fs.mkdirSync(full, { recursive: true });
}

// API routes
app.use('/api/hunts', huntsRouter);
app.use('/api/play', playRouter);
app.use('/api/upload', uploadRouter);

app.get('/health', (req, res) => res.json({ status: 'ok' }));

// SPA fallback (a shared link like /?join=CODE lands on the web app).
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'www', 'index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`🏴‍☠️  Hunter mobile server running on port ${PORT}`);
});
