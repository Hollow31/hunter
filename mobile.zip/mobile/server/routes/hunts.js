const express = require('express');
const { v4: uuidv4 } = require('uuid');
const {
  readHunts,
  writeHunts,
  findHuntById,
  findHuntByCode,
  defaultConfig
} = require('../lib/data');
const { generateJoinCode, generateToken } = require('../lib/codes');

const router = express.Router();

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function getToken(req) {
  const header = req.headers['x-organizer-token'];
  if (header) return header;
  const auth = req.headers.authorization;
  if (auth && auth.startsWith('Bearer ')) return auth.slice(7);
  return req.query.token || null;
}

function requireOrganizer(req, res) {
  const hunt = findHuntById(req.params.huntId);
  if (!hunt) {
    res.status(404).json({ error: 'Chasse introuvable.' });
    return null;
  }
  const token = getToken(req);
  if (!token || token !== hunt.organizerToken) {
    res.status(401).json({ error: 'Jeton organisateur invalide.' });
    return null;
  }
  return hunt;
}

// Only keep configuration fields we accept from the client.
function sanitizeConfig(input) {
  const cfg = defaultConfig();
  if (!input || typeof input !== 'object') return cfg;

  if (typeof input.title === 'string') cfg.title = input.title.slice(0, 120);
  if (typeof input.subtitle === 'string') cfg.subtitle = input.subtitle.slice(0, 240);
  if (typeof input.finalMessage === 'string') cfg.finalMessage = input.finalMessage.slice(0, 2000);
  if (typeof input.finalImage === 'string') cfg.finalImage = input.finalImage.slice(0, 500);

  if (input.theme && typeof input.theme === 'object') {
    cfg.theme = {
      primaryColor: String(input.theme.primaryColor || cfg.theme.primaryColor).slice(0, 20),
      secondaryColor: String(input.theme.secondaryColor || cfg.theme.secondaryColor).slice(0, 20),
      accentColor: String(input.theme.accentColor || cfg.theme.accentColor).slice(0, 20)
    };
  }

  if (Array.isArray(input.helpPhones)) {
    cfg.helpPhones = input.helpPhones
      .filter(p => p && typeof p === 'object')
      .slice(0, 5)
      .map(p => ({
        label: String(p.label || '').slice(0, 40),
        number: String(p.number || '').slice(0, 30)
      }));
  }

  if (Array.isArray(input.steps)) {
    cfg.steps = input.steps.slice(0, 50).map((step, i) => sanitizeStep(step, i));
  }

  return cfg;
}

const VALID_TYPES = [
  'single_answer', 'multiple_answers', 'multi_questions', 'matching',
  'cipher', 'order', 'qcm', 'puzzle', 'photo_upload'
];

function sanitizeStep(step, index) {
  const s = step && typeof step === 'object' ? step : {};
  const type = VALID_TYPES.includes(s.type) ? s.type : 'single_answer';
  const out = {
    id: index + 1,
    title: String(s.title || `Étape ${index + 1}`).slice(0, 120),
    description: String(s.description || '').slice(0, 3000),
    type,
    image: String(s.image || '').slice(0, 500),
    hint: String(s.hint || '').slice(0, 1000)
  };

  if (type === 'single_answer' || type === 'puzzle' || type === 'cipher') {
    out.answers = toStringArray(s.answers);
  }
  if (type === 'multiple_answers') {
    out.answers = toStringArray(s.answers);
    if (Array.isArray(s.fieldLabels)) out.fieldLabels = s.fieldLabels.map(x => String(x).slice(0, 80));
  }
  if (type === 'qcm') {
    out.choices = toStringArray(s.choices);
    out.answers = toStringArray(s.answers);
  }
  if (type === 'matching') {
    out.pairs = (Array.isArray(s.pairs) ? s.pairs : [])
      .filter(p => p && typeof p === 'object')
      .map(p => ({ left: String(p.left || '').slice(0, 120), right: String(p.right || '').slice(0, 120) }));
  }
  if (type === 'order') {
    out.correctOrder = toStringArray(s.correctOrder);
  }
  if (type === 'multi_questions') {
    out.questions = (Array.isArray(s.questions) ? s.questions : [])
      .filter(q => q && typeof q === 'object')
      .map(q => ({
        description: String(q.description || '').slice(0, 500),
        hint: String(q.hint || '').slice(0, 500),
        answers: toStringArray(q.answers)
      }));
  }
  return out;
}

function toStringArray(v) {
  if (!Array.isArray(v)) return [];
  return v.map(x => String(x)).filter(x => x.length > 0).slice(0, 30);
}

// Return the config exposed to a player (WITHOUT the answers).
function publicHunt(hunt) {
  return {
    huntId: hunt.id,
    joinCode: hunt.joinCode,
    title: hunt.config.title,
    subtitle: hunt.config.subtitle,
    theme: hunt.config.theme,
    helpPhones: hunt.config.helpPhones || [],
    totalSteps: (hunt.config.steps || []).length
  };
}

// ---------------------------------------------------------------------------
// Routes
// ---------------------------------------------------------------------------

// Create a new (empty) hunt. Returns the secret organizer token + join code.
router.post('/', (req, res) => {
  const hunts = readHunts();

  // Ensure a unique join code
  let joinCode;
  do {
    joinCode = generateJoinCode(6);
  } while (hunts.some(h => h.joinCode === joinCode));

  const hunt = {
    id: uuidv4(),
    joinCode,
    organizerToken: generateToken(),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    config: sanitizeConfig(req.body && req.body.config),
    teams: []
  };

  hunts.push(hunt);
  writeHunts(hunts);

  res.status(201).json({
    huntId: hunt.id,
    joinCode: hunt.joinCode,
    organizerToken: hunt.organizerToken,
    config: hunt.config
  });
});

// Resolve a join code to public info (used by players before joining).
router.get('/code/:code', (req, res) => {
  const hunt = findHuntByCode(req.params.code);
  if (!hunt) {
    return res.status(404).json({ error: 'Aucune chasse ne correspond à ce code.' });
  }
  if (!hunt.config.steps || hunt.config.steps.length === 0) {
    return res.status(409).json({ error: 'Cette chasse n\'a pas encore d\'étapes.' });
  }
  res.json(publicHunt(hunt));
});

// Get the FULL config of a hunt (organizer only, includes answers).
router.get('/:huntId', (req, res) => {
  const hunt = requireOrganizer(req, res);
  if (!hunt) return;
  res.json({
    huntId: hunt.id,
    joinCode: hunt.joinCode,
    createdAt: hunt.createdAt,
    updatedAt: hunt.updatedAt,
    config: hunt.config
  });
});

// Update the config of a hunt (organizer only).
router.put('/:huntId', (req, res) => {
  const hunt = requireOrganizer(req, res);
  if (!hunt) return;

  const hunts = readHunts();
  const idx = hunts.findIndex(h => h.id === hunt.id);
  hunts[idx].config = sanitizeConfig(req.body && req.body.config);
  hunts[idx].updatedAt = new Date().toISOString();
  writeHunts(hunts);

  res.json({ huntId: hunt.id, config: hunts[idx].config });
});

// Delete a hunt entirely (organizer only).
router.delete('/:huntId', (req, res) => {
  const hunt = requireOrganizer(req, res);
  if (!hunt) return;
  const hunts = readHunts().filter(h => h.id !== hunt.id);
  writeHunts(hunts);
  res.json({ message: 'Chasse supprimée.' });
});

// A player joins a hunt by code (creates a team).
router.post('/:huntId/join', (req, res) => {
  const { name, members } = req.body || {};
  if (!name || typeof name !== 'string' || name.trim().length === 0) {
    return res.status(400).json({ error: 'Le nom d\'équipe est requis.' });
  }
  if (name.trim().length > 50) {
    return res.status(400).json({ error: 'Nom d\'équipe trop long (max 50).' });
  }

  const hunts = readHunts();
  const idx = hunts.findIndex(h => h.id === req.params.huntId);
  if (idx === -1) {
    return res.status(404).json({ error: 'Chasse introuvable.' });
  }
  const hunt = hunts[idx];
  if (!hunt.config.steps || hunt.config.steps.length === 0) {
    return res.status(409).json({ error: 'Cette chasse n\'a pas encore d\'étapes.' });
  }

  if (hunt.teams.some(t => t.name.toLowerCase() === name.trim().toLowerCase())) {
    return res.status(409).json({ error: 'Ce nom d\'équipe est déjà pris.' });
  }

  const team = {
    id: uuidv4(),
    name: name.trim(),
    members: Array.isArray(members) ? members.slice(0, 20).map(m => String(m).slice(0, 40)) : [],
    currentStep: 1,
    completedSteps: [],
    attempts: {},
    photos: {},
    startedAt: new Date().toISOString(),
    completedAt: null
  };

  hunt.teams.push(team);
  writeHunts(hunts);

  res.status(201).json({
    teamId: team.id,
    huntId: hunt.id,
    teamName: team.name,
    totalSteps: hunt.config.steps.length,
    ...publicHunt(hunt)
  });
});

// Resume a team by name inside a hunt.
router.post('/:huntId/resume', (req, res) => {
  const { name } = req.body || {};
  const hunt = findHuntById(req.params.huntId);
  if (!hunt) {
    return res.status(404).json({ error: 'Chasse introuvable.' });
  }
  const team = hunt.teams.find(t => t.name.toLowerCase() === String(name || '').trim().toLowerCase());
  if (!team) {
    return res.status(404).json({ error: 'Équipe non trouvée.' });
  }
  res.json({
    teamId: team.id,
    huntId: hunt.id,
    teamName: team.name,
    completedSteps: team.completedSteps,
    totalSteps: hunt.config.steps.length,
    ...publicHunt(hunt)
  });
});

// Organizer monitoring: list of teams and their progress.
router.get('/:huntId/teams', (req, res) => {
  const hunt = requireOrganizer(req, res);
  if (!hunt) return;
  const totalSteps = hunt.config.steps.length;
  const summary = hunt.teams.map(t => ({
    id: t.id,
    name: t.name,
    members: t.members,
    completedSteps: t.completedSteps || [],
    totalSteps,
    startedAt: t.startedAt,
    completedAt: t.completedAt,
    totalAttempts: Object.values(t.attempts || {}).reduce((a, b) => a + b, 0),
    photos: t.photos || {}
  }));
  res.json({ joinCode: hunt.joinCode, title: hunt.config.title, totalSteps, teams: summary });
});

// Organizer: delete one team.
router.delete('/:huntId/teams/:teamId', (req, res) => {
  const hunt = requireOrganizer(req, res);
  if (!hunt) return;
  const hunts = readHunts();
  const idx = hunts.findIndex(h => h.id === hunt.id);
  hunts[idx].teams = hunts[idx].teams.filter(t => t.id !== req.params.teamId);
  writeHunts(hunts);
  res.json({ message: 'Équipe supprimée.' });
});

module.exports = router;
