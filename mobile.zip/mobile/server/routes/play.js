const express = require('express');
const { readHunts, writeHunts, findHuntById } = require('../lib/data');
const { validateAnswer } = require('../lib/validators');

const router = express.Router();

const TYPE_ICONS = {
  single_answer: '✏️',
  multiple_answers: '📝',
  multi_questions: '📝',
  matching: '🔗',
  cipher: '🔐',
  order: '📋',
  qcm: '🎯',
  puzzle: '🧩',
  photo_upload: '📷'
};

function locate(huntId, teamId) {
  const hunt = findHuntById(huntId);
  if (!hunt) return { error: 'Chasse introuvable.', status: 404 };
  const team = hunt.teams.find(t => t.id === teamId);
  if (!team) return { error: 'Équipe non trouvée.', status: 404 };
  return { hunt, team };
}

// Steps overview (hub) for a team.
router.get('/:huntId/:teamId/steps', (req, res) => {
  const { hunt, team, error, status } = locate(req.params.huntId, req.params.teamId);
  if (error) return res.status(status).json({ error });

  const steps = hunt.config.steps.map((step, i) => ({
    number: i + 1,
    title: step.title,
    type: step.type,
    icon: TYPE_ICONS[step.type] || '❓',
    isCompleted: team.completedSteps.includes(i + 1)
  }));

  res.json({
    teamName: team.name,
    title: hunt.config.title,
    theme: hunt.config.theme,
    totalSteps: hunt.config.steps.length,
    completedCount: team.completedSteps.length,
    allCompleted: team.completedSteps.length >= hunt.config.steps.length,
    steps
  });
});

// Final page (only if everything is completed).
router.get('/:huntId/:teamId/final', (req, res) => {
  const { hunt, team, error, status } = locate(req.params.huntId, req.params.teamId);
  if (error) return res.status(status).json({ error });

  if (team.completedSteps.length < hunt.config.steps.length) {
    return res.status(403).json({ error: 'Toutes les étapes ne sont pas encore validées.' });
  }

  const startTime = new Date(team.startedAt);
  const endTime = new Date(team.completedAt || Date.now());
  const duration = Math.max(0, Math.floor((endTime - startTime) / 1000));
  const minutes = Math.floor(duration / 60);
  const seconds = duration % 60;

  res.json({
    teamName: team.name,
    finalMessage: hunt.config.finalMessage,
    finalImage: hunt.config.finalImage || null,
    duration: `${minutes}min ${seconds}s`,
    totalAttempts: Object.values(team.attempts || {}).reduce((a, b) => a + b, 0)
  });
});

// Get a single step for a team (WITHOUT answers).
router.get('/:huntId/:teamId/step/:stepNumber', (req, res) => {
  const { hunt, team, error, status } = locate(req.params.huntId, req.params.teamId);
  if (error) return res.status(status).json({ error });

  const stepNum = parseInt(req.params.stepNumber, 10);
  if (isNaN(stepNum) || stepNum < 1 || stepNum > hunt.config.steps.length) {
    return res.status(400).json({ error: 'Numéro d\'étape invalide.' });
  }
  const step = hunt.config.steps[stepNum - 1];

  const safeStep = {
    id: step.id,
    number: stepNum,
    title: step.title,
    description: step.description,
    type: step.type,
    image: step.image || null,
    hint: step.hint || null,
    totalSteps: hunt.config.steps.length,
    isCompleted: team.completedSteps.includes(stepNum)
  };

  if (step.type === 'matching') {
    safeStep.leftItems = step.pairs.map(p => p.left);
    safeStep.rightItems = step.pairs.map(p => p.right).sort(() => Math.random() - 0.5);
  }
  if (step.type === 'order') {
    safeStep.items = [...step.correctOrder].sort(() => Math.random() - 0.5);
  }
  if (step.type === 'qcm') {
    safeStep.choices = step.choices;
    safeStep.multiSelect = step.answers.length > 1;
  }
  if (step.type === 'multiple_answers') {
    safeStep.fieldCount = step.answers.length;
    safeStep.fieldLabels = step.fieldLabels || null;
  }
  if (step.type === 'multi_questions') {
    safeStep.questions = step.questions.map(q => ({ description: q.description, hint: q.hint || null }));
  }

  res.json(safeStep);
});

// Submit an answer for a step.
router.post('/:huntId/:teamId/step/:stepNumber/answer', (req, res) => {
  const { hunt, team, error, status } = locate(req.params.huntId, req.params.teamId);
  if (error) return res.status(status).json({ error });

  const stepNum = parseInt(req.params.stepNumber, 10);
  if (isNaN(stepNum) || stepNum < 1 || stepNum > hunt.config.steps.length) {
    return res.status(400).json({ error: 'Numéro d\'étape invalide.' });
  }
  const step = hunt.config.steps[stepNum - 1];

  if (team.completedSteps.includes(stepNum)) {
    return res.json({ valid: true, message: 'Étape déjà validée.', alreadyDone: true });
  }

  const { answer } = req.body || {};
  const result = validateAnswer(answer, step);

  // Count the attempt
  team.attempts[stepNum] = (team.attempts[stepNum] || 0) + 1;

  if (result.valid) {
    team.completedSteps.push(stepNum);
    if (team.completedSteps.length >= hunt.config.steps.length) {
      team.completedAt = new Date().toISOString();
    }
  }

  // Persist
  const hunts = readHunts();
  const hIdx = hunts.findIndex(h => h.id === hunt.id);
  const tIdx = hunts[hIdx].teams.findIndex(t => t.id === team.id);
  hunts[hIdx].teams[tIdx] = team;
  writeHunts(hunts);

  res.json({
    valid: result.valid,
    message: result.message,
    wrongIndices: result.wrongIndices || null,
    isFinished: team.completedSteps.length >= hunt.config.steps.length,
    hint: !result.valid && (team.attempts[stepNum] >= 3) ? (step.hint || null) : null
  });
});

module.exports = router;
