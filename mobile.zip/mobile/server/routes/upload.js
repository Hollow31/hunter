const express = require('express');
const fs = require('fs');
const path = require('path');
const { readHunts, writeHunts, findHuntById } = require('../lib/data');

const router = express.Router();

const UPLOADS_DIR = path.join(__dirname, '..', 'uploads');

// Upload a photo for a photo_upload step (base64 JSON).
router.post('/:huntId/:teamId/:stepNumber', (req, res) => {
  const { huntId, teamId, stepNumber } = req.params;
  const stepNum = parseInt(stepNumber, 10);

  const hunt = findHuntById(huntId);
  if (!hunt) return res.status(404).json({ error: 'Chasse introuvable.' });

  const teams = hunt.teams;
  const teamIndex = teams.findIndex(t => t.id === teamId);
  if (teamIndex === -1) return res.status(404).json({ error: 'Équipe non trouvée.' });
  const team = teams[teamIndex];

  if (isNaN(stepNum) || stepNum < 1 || stepNum > hunt.config.steps.length) {
    return res.status(400).json({ error: 'Numéro d\'étape invalide.' });
  }
  const step = hunt.config.steps[stepNum - 1];
  if (step.type !== 'photo_upload') {
    return res.status(400).json({ error: 'Cette étape n\'est pas de type photo.' });
  }
  if (team.completedSteps.includes(stepNum)) {
    return res.status(400).json({ error: 'Cette étape a déjà été validée.' });
  }

  const { photo, mimeType } = req.body || {};
  if (!photo || !mimeType) {
    return res.status(400).json({ error: 'Aucune photo reçue.' });
  }
  if (!mimeType.startsWith('image/')) {
    return res.status(400).json({ error: 'Le fichier doit être une image.' });
  }

  const buffer = Buffer.from(photo, 'base64');
  if (buffer.length === 0) {
    return res.status(400).json({ error: 'Aucune photo reçue.' });
  }
  if (buffer.length > 10 * 1024 * 1024) {
    return res.status(400).json({ error: 'La photo est trop volumineuse (max 10 Mo).' });
  }

  const extMap = { 'image/jpeg': '.jpg', 'image/png': '.png', 'image/webp': '.webp', 'image/gif': '.gif' };
  const ext = extMap[mimeType] || '.jpg';

  const photosDir = path.join(UPLOADS_DIR, huntId);
  if (!fs.existsSync(photosDir)) {
    fs.mkdirSync(photosDir, { recursive: true });
  }

  const safeName = team.name.replace(/[^a-zA-Z0-9_-]/g, '_').substring(0, 30);
  const filename = `${safeName}_step${stepNum}${ext}`;
  fs.writeFileSync(path.join(photosDir, filename), buffer);

  team.completedSteps.push(stepNum);
  team.attempts[stepNum] = (team.attempts[stepNum] || 0) + 1;
  const isLastStep = team.completedSteps.length >= hunt.config.steps.length;
  if (isLastStep) {
    team.completedAt = new Date().toISOString();
  }
  if (!team.photos) team.photos = {};
  team.photos[stepNum] = `/api/upload/photo/${huntId}/${filename}`;

  const hunts = readHunts();
  const hIdx = hunts.findIndex(h => h.id === huntId);
  hunts[hIdx].teams[teamIndex] = team;
  writeHunts(hunts);

  res.json({
    valid: true,
    message: 'Photo enregistrée avec succès !',
    photoUrl: `/api/upload/photo/${huntId}/${filename}`,
    isFinished: isLastStep
  });
});

// Serve an uploaded photo.
router.get('/photo/:huntId/:filename', (req, res) => {
  const { huntId, filename } = req.params;
  if (!/^[a-zA-Z0-9-]+$/.test(huntId) || !/^[a-zA-Z0-9_\-]+\.\w+$/.test(filename)) {
    return res.status(400).json({ error: 'Chemin invalide.' });
  }
  const filepath = path.join(UPLOADS_DIR, huntId, filename);
  if (!fs.existsSync(filepath)) {
    return res.status(404).json({ error: 'Photo non trouvée.' });
  }
  res.sendFile(filepath);
});

module.exports = router;
